/**
 * 战斗 UI 绘制(M4d-1)—— 队员信息框 / 框式指令菜单 / 当前行动者手指。
 *
 * UX 形态参照一阶段战斗 UI(playerbox+头像+黄青错落数字,91+77i,165),实现全部
 * 复用 D17 菜单基建(drawSlicedBox 九宫格 / renderSpans 字模 / drawNumber 预烘数字);
 * 320 逻辑坐标,调用方已 ctx.scale。资产缺省时调用方走文字兜底(单测/加载失败容错)。
 */

import {
  COLOR_DISABLED,
  COLOR_DISABLED_SEL,
  COLOR_NORMAL,
  drawNumber,
  drawScroll,
  drawSlicedBox,
  type MenuAssets,
  SELECTED_COLORS,
} from '../menu/menu-box.js'
import type { GlyphTable } from '../text/glyph.js'
import { renderSpans } from '../text/text-render.js'

// ── 队员信息框(一阶段 91+77i,165;playerbox 75×35 贴屏底)──────────────
const INFO_X_BASE = 91
const INFO_X_STEP = 77
const INFO_Y = 165
// HP/MP 错落布局(一阶段 uibattle 考证):cur 右缘 x+50 / slash x+49 / max 右缘 x+71
const NUM_CUR_RIGHT = 50
const NUM_MAX_RIGHT = 71
const SLASH_X = 49
const HP_CUR_Y = 5
const HP_SLASH_Y = 6
const HP_MAX_Y = 8
const MP_CUR_Y = 21
const MP_SLASH_Y = 22
const MP_MAX_Y = 24

// ── 竖排小盒(杂项盒/使用投掷盒;一阶段杂项盒 box(2,20) 项(16,32) → 盒内偏移 14,12)──
const MENU_PAD_X = 14
const MENU_PAD_Y = 12
const MENU_ITEM_H = 18
/** 已确认父项固定色(一阶段 MENUITEM_COLOR_CONFIRMED 0x2C 金黄)。 */
const COLOR_CONFIRMED = [255, 203, 113] as const

// ── 主菜单 4 图标(一阶段 uibattle 真值:攻击/法术/合击/杂项,菱形布局)──
const MAIN_ICON_POS: ReadonlyArray<{ x: number; y: number }> = [
  { x: 27, y: 140 }, // 攻击
  { x: 0, y: 155 }, // 法术
  { x: 54, y: 155 }, // 合击
  { x: 27, y: 170 }, // 杂项
]

// ── 3 列分页网格(一阶段 magicmenu/itemmenu 真值)──
export interface GridLayout {
  box: { x: number; y: number; w: number; h: number }
  item0: { x: number; y: number }
  colW: number
  rowH: number
  rows: number
  /** 分页偏移行数(pageStart = floor(cursor/3)*3 − 3*offset)。 */
  pageOffset: number
  /** 数量数字相对 item x 的右缘偏移;undefined = 不画(法术网格)。 */
  amountX?: number
}
/** 法术网格:box(10,42) 4 行中段 → 300×114;项 (35,54)+col*87+row*18,显示 5 行。 */
export const MAGIC_GRID: GridLayout = {
  box: { x: 10, y: 42, w: 300, h: 114 },
  item0: { x: 35, y: 54 },
  colW: 87,
  rowH: 18,
  rows: 5,
  pageOffset: 2,
}
/** 物品网格:box(2,0) 6 行中段 → 316×150;项 (15,12)+col*100+row*18,显示 7 行,数量 @+81。 */
export const ITEM_GRID: GridLayout = {
  box: { x: 2, y: 0, w: 316, h: 150 },
  item0: { x: 15, y: 12 },
  colW: 100,
  rowH: 18,
  rows: 7,
  pageOffset: 4,
  amountX: 81,
}

export interface InfoBoxPlayer {
  roleId: string
  hp: number
  maxHp: number
  mp: number
  maxMp: number
  /** 坏状态剩余回合(状态字:乱/定/眠/封;缺省不画)。 */
  status?: { confused?: number; paralyzed?: number; sleep?: number; silence?: number }
  /** 中毒头像单色化的颜色([r,g,b];最高级 ≤3 毒的 wColor 经调色板;undefined = 无毒正常)。 */
  poisonRgb?: readonly [number, number, number]
}

/**
 * 信息框状态字(uibattle.c:60-104 rgStatusPos/rgwStatusWord/rgbStatusColor):
 * 仅乱/定/眠/封 4 个坏状态显字,坐标为框内偏移,颜色 = 调色板索引(此处已换算 RGB)。
 * 仅活人画(hp>0,uibattle.c:243)。
 */
const STATUS_WORDS: ReadonlyArray<{
  key: 'confused' | 'paralyzed' | 'sleep' | 'silence'
  text: string
  dx: number
  dy: number
  colorIdx: number
}> = [
  { key: 'confused', text: '乱', dx: 35, dy: 19, colorIdx: 0x5f },
  { key: 'paralyzed', text: '定', dx: 44, dy: 12, colorIdx: 0xbf },
  { key: 'sleep', text: '眠', dx: 54, dy: 1, colorIdx: 0x0e },
  { key: 'silence', text: '封', dx: 55, dy: 20, colorIdx: 0x3c },
]

/** 毒色头像缓存(roleId+rgb → 单色化位图;每帧 getImageData 太贵)。 */
const poisonFaceCache = new Map<string, HTMLCanvasElement>()

/** PAL_RLEBlitMonoColor 的 RGBA 近似:保亮度,色相/饱和取毒色(乘法调制)。 */
function monoColorFace(
  face: ImageBitmap,
  rgb: readonly [number, number, number],
  key: string,
): HTMLCanvasElement {
  const hit = poisonFaceCache.get(key)
  if (hit) return hit
  const cvs = document.createElement('canvas')
  cvs.width = face.width
  cvs.height = face.height
  const c = cvs.getContext('2d')
  if (!c) throw new Error('monoColorFace: 2d canvas unavailable')
  c.drawImage(face, 0, 0)
  const img = c.getImageData(0, 0, cvs.width, cvs.height)
  const d = img.data
  for (let i = 0; i < d.length; i += 4) {
    if (d[i + 3] === 0) continue
    // 亮度 × 毒色(原版 mono 色阶按调色板同色系渐变;RGBA 近似 = luma 调制)
    const luma = ((d[i] ?? 0) * 0.299 + (d[i + 1] ?? 0) * 0.587 + (d[i + 2] ?? 0) * 0.114) / 255
    d[i] = Math.round(rgb[0] * luma)
    d[i + 1] = Math.round(rgb[1] * luma)
    d[i + 2] = Math.round(rgb[2] * luma)
  }
  c.putImageData(img, 0, 0)
  poisonFaceCache.set(key, cvs)
  return cvs
}

/** 队员信息框一枚:框 + 头像(死亡灰化/中毒单色化)+ HP 黄 / MP 青错落数字 + 状态字。 */
export function drawPlayerInfoBox(
  ctx: CanvasRenderingContext2D,
  menu: MenuAssets,
  face: ImageBitmap | undefined,
  p: InfoBoxPlayer,
  slot: number,
  glyphs?: GlyphTable,
  palette?: import('@type-pal/shared').Palette,
): void {
  const x = INFO_X_BASE + slot * INFO_X_STEP
  const y = INFO_Y
  if (menu.magicPlayerBox) ctx.drawImage(menu.magicPlayerBox, x, y)
  if (face) {
    if (p.hp <= 0) {
      ctx.save()
      ctx.filter = 'grayscale(1) brightness(0.6)' // 死亡:一阶段 mono 黑白的 RGBA 等价
      ctx.drawImage(face, x - 2, y - 4)
      ctx.restore()
    } else if (p.poisonRgb) {
      // 中毒:头像按最高级毒 wColor 单色化(uibattle.c:158-161 PAL_RLEBlitMonoColor)
      ctx.drawImage(
        monoColorFace(face, p.poisonRgb, `${p.roleId}:${p.poisonRgb.join(',')}`),
        x - 2,
        y - 4,
      )
    } else {
      ctx.drawImage(face, x - 2, y - 4)
    }
  }
  if (menu.slash) {
    ctx.drawImage(menu.slash, x + SLASH_X, y + HP_SLASH_Y)
    ctx.drawImage(menu.slash, x + SLASH_X, y + MP_SLASH_Y)
  }
  drawNumber(ctx, p.hp, x + NUM_CUR_RIGHT, y + HP_CUR_Y, menu.nums)
  drawNumber(ctx, p.maxHp, x + NUM_MAX_RIGHT, y + HP_MAX_Y, menu.nums)
  drawNumber(ctx, p.mp, x + NUM_CUR_RIGHT, y + MP_CUR_Y, menu.numsCyan)
  drawNumber(ctx, p.maxMp, x + NUM_MAX_RIGHT, y + MP_MAX_Y, menu.numsCyan)
  // 状态字(仅活人;uibattle.c:243-255。颜色 = 调色板索引直查,无调色板不画)
  if (glyphs && palette && p.status && p.hp > 0) {
    for (const w of STATUS_WORDS) {
      if ((p.status[w.key] ?? 0) <= 0) continue
      const rgb = palette.colors[w.colorIdx]
      if (!rgb) continue
      renderSpans(ctx, [{ text: w.text }], x + w.dx, y + w.dy, {
        glyphs,
        shadow: true,
        forceRgba: rgb,
      })
    }
  }
}

export interface BattleMenuRow {
  label: string
  disabled?: boolean
  /** 行右侧数值(仙术 MP / 物品数量);黄数字右对齐。 */
  right?: number
}

/**
 * 竖排小盒菜单(杂项盒/使用投掷盒,一阶段 uibattle 杂项盒布局)。返回框宽。
 * w/h 定死传入(一阶段盒 = tile 网格 (cols+2)×16,杂项 64×96 / 二级 48×48),
 * **不随文字动态撑宽** —— 作者点名的惯犯:菜单盒按原版定尺寸,文字长了压边是原版本样。
 * confirmed=true:当前项固定金黄(已进二级,父项确认色 0x2C),其余不闪。
 */
export function drawBattleMenuBox(
  ctx: CanvasRenderingContext2D,
  menu: MenuAssets,
  glyphs: GlyphTable,
  rows: BattleMenuRow[],
  cursor: number,
  now: number,
  x: number,
  y: number,
  w: number,
  h: number,
  confirmed = false,
): number {
  drawSlicedBox(ctx, menu.box, x, y, w, h)
  const blink = SELECTED_COLORS[Math.floor(now / 100) % SELECTED_COLORS.length] ?? COLOR_NORMAL
  rows.forEach((r, i) => {
    const selected = i === cursor
    let color: readonly [number, number, number]
    if (r.disabled) color = selected ? COLOR_DISABLED_SEL : COLOR_DISABLED
    else if (selected) color = confirmed ? COLOR_CONFIRMED : blink
    else color = COLOR_NORMAL
    const ry = y + MENU_PAD_Y + i * MENU_ITEM_H
    renderSpans(ctx, [{ text: r.label }], x + MENU_PAD_X, ry, {
      glyphs,
      shadow: true,
      forceRgba: color,
    })
    if (r.right !== undefined) {
      drawNumber(ctx, r.right, x + w - 14, ry + 5, r.disabled ? menu.numsBlue : menu.nums)
    }
  })
  return w
}

/** Engine chrome owns its color ramps, just like the baked menu text and number sprites.
 * Palette-0 entries 0..31 (source hash in engine-chrome/assets/PROVENANCE.md).
 * A project palette can contain arbitrary artwork colors here; it must never recolor chrome.
 */
const ICON_GRAY = [0, 24, 40, 56, 73, 89, 105, 121, 138, 154, 170, 186, 203, 219, 239, 255]
const ICON_RED = [
  [52, 0, 0],
  [69, 0, 0],
  [81, 0, 0],
  [93, 4, 4],
  [109, 8, 4],
  [121, 16, 12],
  [138, 24, 20],
  [150, 32, 24],
  [166, 40, 32],
  [178, 56, 44],
  [190, 73, 60],
  [203, 89, 77],
  [215, 109, 93],
  [227, 130, 113],
  [239, 150, 134],
  [255, 174, 158],
] as const
/** Cache by actual bitmap, not a slot shared across replacement images or trial runs. */
const monoIconCache = new WeakMap<ImageBitmap, Map<number, HTMLCanvasElement>>()

/**
 * PAL_RLEBlitMonoColor 的 RGBA 版(palcommon.c:446,经一阶段 blitSpriteMonoColor):
 * 每不透明像素取明度档(≈原索引低 nibble),+shift clamp[0,15],查 chrome 自有色带上色。
 * band 0x00 = 灰组(灰阶);band 0x10 = 红组(**暗红** —— 作者点破「原版一定有红」,对)。
 */
function monoIcon(img: ImageBitmap, band: number, shift: number): HTMLCanvasElement {
  const variants = monoIconCache.get(img) ?? new Map<number, HTMLCanvasElement>()
  const hit = variants.get(band)
  if (hit) return hit
  const cvs = document.createElement('canvas')
  cvs.width = img.width
  cvs.height = img.height
  const c = cvs.getContext('2d')
  if (!c) throw new Error('monoIcon: 2d canvas unavailable')
  c.drawImage(img, 0, 0)
  const im = c.getImageData(0, 0, cvs.width, cvs.height)
  const d = im.data
  for (let i = 0; i < d.length; i += 4) {
    if (d[i + 3] === 0) continue
    const luma = 0.299 * (d[i] ?? 0) + 0.587 * (d[i + 1] ?? 0) + 0.114 * (d[i + 2] ?? 0)
    let lv = Math.round((luma / 255) * 15) + shift
    lv = lv < 0 ? 0 : lv > 15 ? 15 : lv
    const gray = ICON_GRAY[lv] ?? 0
    const col = band === 0x10 ? (ICON_RED[lv] ?? ICON_RED[0]) : [gray, gray, gray]
    d[i] = col[0] ?? 0
    d[i + 1] = col[1] ?? 0
    d[i + 2] = col[2] ?? 0
  }
  c.putImageData(im, 0, 0)
  variants.set(band, cvs)
  monoIconCache.set(img, variants)
  return cvs
}

/**
 * 主菜单 4 图标(一阶段 uibattle.c:1067-1078 三态):选中=全彩;可用未选=灰
 * (MonoColor 0x00,−4);不可用=**暗红**(MonoColor 0x10,−4)。不消费工程美术色盘。
 * icons 序 = 0攻击 1法术 2合击 3杂项。
 */
export function drawMainIcons(
  ctx: CanvasRenderingContext2D,
  icons: (ImageBitmap | undefined)[],
  selected: number,
  valid: readonly boolean[],
  highlight: boolean,
): void {
  MAIN_ICON_POS.forEach((pos, i) => {
    const img = icons[i]
    if (!img) return
    if (highlight && i === selected) {
      ctx.drawImage(img, pos.x, pos.y) // 选中 = 全彩
      return
    }
    const band = valid[i] ? 0x00 : 0x10
    ctx.drawImage(monoIcon(img, band, -4), pos.x, pos.y)
  })
}

/**
 * 3 列分页网格(一阶段 magicmenu/itemmenu):红框 + 逐格上色 + 手指光标 + (物品)数量。
 */
export function drawBattleGrid(
  ctx: CanvasRenderingContext2D,
  menu: MenuAssets,
  glyphs: GlyphTable,
  rows: BattleMenuRow[],
  cursor: number,
  now: number,
  lay: GridLayout,
): void {
  drawSlicedBox(ctx, menu.redBox, lay.box.x, lay.box.y, lay.box.w, lay.box.h)
  const blink = SELECTED_COLORS[Math.floor(now / 100) % SELECTED_COLORS.length] ?? COLOR_NORMAL
  let pageStart = Math.floor(cursor / 3) * 3 - 3 * lay.pageOffset
  if (pageStart < 0) pageStart = 0
  let i = pageStart
  outer: for (let row = 0; row < lay.rows; row++) {
    for (let col = 0; col < 3; col++) {
      if (i >= rows.length) break outer
      const r = rows[i]
      if (!r) continue
      const selected = i === cursor
      let color: readonly [number, number, number]
      if (selected) color = r.disabled ? COLOR_DISABLED_SEL : blink
      else color = r.disabled ? COLOR_DISABLED : COLOR_NORMAL
      const x = lay.item0.x + col * lay.colW
      const y = lay.item0.y + row * lay.rowH
      renderSpans(ctx, [{ text: r.label }], x, y, { glyphs, shadow: true, forceRgba: color })
      if (lay.amountX !== undefined && r.right !== undefined && r.right > 1) {
        drawNumber(ctx, r.right, x + lay.amountX, y + 5, menu.numsCyan)
      }
      if (selected && menu.cursorGrid) ctx.drawImage(menu.cursorGrid, x + 25, y + 10)
      i++
    }
  }
}

/** 法术网格左上 MP 框(一阶段 WIN95 布局):卷轴(0,0)len5 + needed 黄 / slash / current 青。 */
export function drawMpBox(
  ctx: CanvasRenderingContext2D,
  menu: MenuAssets,
  needed: number,
  current: number,
): void {
  drawScroll(ctx, menu.scroll, 0, 0, 5)
  if (menu.slash) ctx.drawImage(menu.slash, 45, 14)
  drawNumber(ctx, needed, 39, 14, menu.nums)
  drawNumber(ctx, current, 74, 14, menu.numsCyan)
}

/** 物品网格左下选中物详情框(一阶段 ITEMBOX@0,140 + 图标 @+8,+7)。 */
export function drawItemDetailBox(
  ctx: CanvasRenderingContext2D,
  menu: MenuAssets,
  icon: ImageBitmap | undefined,
): void {
  drawSlicedBox(ctx, menu.itembox, 0, 140, 64, 64)
  if (icon) ctx.drawImage(icon, 8, 147)
}

/** 当前行动队员头顶三角(一阶段 68红/69常 闪烁)。
 *  锚 = 底中偏移 (−8, −74) **照抄原版 blit**(uibattle.c:1004;CURSOR 帧 9×6,
 *  故三角中心在 pos.x−4 —— 不做 width/2 居中换算,作者原版截图它就在头顶正上)。 */
export function drawCurrentFinger(
  ctx: CanvasRenderingContext2D,
  menu: MenuAssets,
  baseX: number,
  baseY: number,
  now: number,
): void {
  const img = Math.floor(now / 160) % 2 === 0 ? menu.cursorDown : menu.cursorGrid
  if (img) ctx.drawImage(img, baseX - 8, baseY - 74)
}

/** 选队友箭头(一阶段 drawPlayerTargetArrow 1:1):帧 67 常色 / 66 红 40ms 交替
 *  (arrowBlinkRed),贴候选队员底中 (−8, −67)(uibattle.c:1574)。
 *  选队友 = **箭头光标移动**;选敌方才是 colorShift 高亮 —— 两套形制勿混。 */
export function drawPlayerTargetArrow(
  ctx: CanvasRenderingContext2D,
  menu: MenuAssets,
  baseX: number,
  baseY: number,
  now: number,
): void {
  const img = (Math.floor(now / 40) & 1) === 1 ? menu.cursorUpRed : menu.cursorUp
  if (img) ctx.drawImage(img, baseX - 8, baseY - 67)
}
