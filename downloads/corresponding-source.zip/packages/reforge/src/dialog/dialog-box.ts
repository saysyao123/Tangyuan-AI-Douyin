/**
 * 对话框渲染(② 外观 Task 6:slot 共存模型)。
 * 逐段推进 + top/bottom 多槽:同槽覆盖、异槽共存。位置真值 GLM spec §3。
 * 每段话在它的 slot 内自动折行(layoutLines)+ 按 4 显示行/页分页,翻页只翻活跃槽。
 */
import {
  type AssetId,
  type DialogueCue,
  type Locale,
  lookupText,
  parseRichText,
  type TextSpan,
} from '@type-pal/content'
import type { RleFrame } from '@type-pal/shared'
import { advanceCue, type DialogueState } from '../dialogue.js'
import { type BoxTiles, drawScroll } from '../menu/menu-box.js'
import type { GlyphTable } from '../text/glyph.js'
import { CURSOR_COLOR_COUNT, CURSOR_RGBA, colorRgba, TITLE_RGBA } from '../text/palette-color.js'
import { measureSpans, renderSpans } from '../text/text-render.js'
import { charsShown, countChars, DEFAULT_SPEED_MS } from '../text/typewriter.js'
import { bakeCursorTinted } from './dialog-assets.js'
import { type DisplayLine, layoutLines } from './layout.js'
import { narrationScrollLayout } from './narration-scroll.js'
import { advanceSlots, emptySlots, type SlotId, type SlotState } from './slot.js'

// GLM spec §3 布局真值(320×200 坐标系)。无头像 / 有头像两种正文+姓名 x(spec §3 hasPortrait 三元)。
const LINE_HEIGHT = 18
const LINES_PER_PAGE = 4 // spec §3:MAX_LINES_PER_PAGE
const POS = {
  bottom: {
    text: { x: 44, y: 126 },
    title: { x: 12, y: 108 },
    textWithPortrait: { x: 20, y: 126 },
    titleWithPortrait: { x: 4, y: 108 },
    portrait: { x: 270, y: 144 }, // 实际画 (portrait.x - w/2, portrait.y - h/2)
  },
  top: {
    text: { x: 44, y: 26 },
    title: { x: 12, y: 8 },
    textWithPortrait: { x: 96, y: 26 },
    titleWithPortrait: { x: 80, y: 8 },
    portrait: { x: 48, y: 55 },
  },
  // 中央叙述窗(原版 0x3E:宝箱拾取/旁白)。M3a 复用正文排版居中放;专用窗框绘制 M3b 细化。
  narration: {
    text: { x: 60, y: 88 },
    title: { x: 60, y: 72 },
    textWithPortrait: { x: 60, y: 88 },
    titleWithPortrait: { x: 60, y: 72 },
    portrait: { x: -100, y: -100 }, // 叙述窗无头像
  },
  // 居中窗(原版 setDialogStyleCenter:开场独白/剧情大字,偏上)。≠底部叙述窗;一阶段 center={80,40}。
  center: {
    text: { x: 80, y: 40 },
    title: { x: 80, y: 24 },
    textWithPortrait: { x: 80, y: 40 },
    titleWithPortrait: { x: 80, y: 24 },
    portrait: { x: -100, y: -100 }, // 居中窗无头像
  },
} as const
// D14-1:原版全宽语义——文本区右缘 = 屏幕 320(usable = 320 − startX)。原版 sdlpal
// 对话逐行直绘、无自动折行、无框宽裁边,头像只改文本起点;折行只发生在超出
// 原版最大可视宽度的行(全量 11102 行中仅 6 行)。
const MAX_RIGHT = 320

/** center 是无框剧情字幕；narration 自带卷轴，只有上下普通对话显示等键箭头。 */
export function dialogSlotShowsCursor(slotId: SlotId): boolean {
  return slotId === 'top' || slotId === 'bottom'
}

/** 单个 slot 的排版渲染态(slot.ts 管 cueIdx,这里管 cue 内 rows 的排版)。 */
interface SlotRender {
  cue: DialogueCue
  dialogueId: string
  cueIndex: number
  presentationId: number
  pageStartedAtMs: number
  visibleText: string | null
  displayLines: DisplayLine[]
  /** narration 单行卷轴使用未折行的富文本。 */
  singleLineSpans: TextSpan[]
  pageStart: number
  /** 每个源 row 的真实打字速度(ms/字)。 */
  rowSpeeds: number[]
  /** cue 尾停顿自动推进(ms);非 undefined = 自动推进、无光标。 */
  autoAdvance?: number
}

/** Detached observation of the last rendered page; reading never ticks or advances dialogue. */
export interface DialogueObservation {
  readonly dialogueId: string
  readonly cueIndex: number
  readonly slot: SlotId
  readonly pageIndex: number
  readonly pageCount: number
  readonly pageStartedAtMs: number
  readonly phase: 'typing' | 'waiting-input' | 'auto-advance'
  readonly speaker: string | null
  readonly rowTextIds: readonly string[]
  readonly pageTextIds: readonly string[]
  readonly pageText: string
}

/** All configured slots. visibleText is populated only by a successful slot draw. */
export interface DialogueSlotObservation extends Omit<DialogueObservation, 'phase'> {
  readonly presentationId: number
  readonly active: boolean
  readonly phase: DialogueObservation['phase'] | 'retained'
  readonly visibleText: string | null
  readonly portraitAsset: string | null
}

export class DialogBox {
  private state: DialogueState | null = null
  private slots: SlotState = emptySlots()
  private renders: Partial<Record<SlotId, SlotRender>> = {}
  private lineStartMs = 0
  /** 活跃槽当前页是否已全显(fUserSkip 两段式)。 */
  private pageDone = false
  private retainSlots = false
  private nextPresentationId = 0

  private cursorBaked: HTMLCanvasElement[] = []

  constructor(
    private readonly ctx: CanvasRenderingContext2D,
    private readonly glyphs: GlyphTable,
    private readonly cursorFrames: RleFrame[],
    private readonly portraits: ReadonlyMap<AssetId, ImageBitmap> = new Map(),
    private readonly locale: Locale = {},
    private readonly scroll?: BoxTiles,
    private readonly framed = false, // T14_FRAMED_DIALOGUE
  ) {}

  get active(): boolean {
    return this.state !== null
  }

  get visible(): boolean {
    return Object.keys(this.renders).length > 0
  }

  observeSlots(): readonly DialogueSlotObservation[] {
    return Object.freeze(
      (['bottom', 'top', 'narration', 'center'] as const).flatMap((slot) => {
        const render = this.renders[slot]
        if (!render) return []
        const active = this.active && slot === this.slots.activeSlot
        const observation = this.observeSlot(slot, render)
        return [
          Object.freeze({
            ...observation,
            presentationId: render.presentationId,
            active,
            phase: active ? observation.phase : ('retained' as const),
            visibleText: render.visibleText,
            portraitAsset:
              render.cue.portrait && this.portraits.has(render.cue.portrait.asset)
                ? render.cue.portrait.asset
                : null,
          }),
        ]
      }),
    )
  }

  observe(): DialogueObservation | null {
    const state = this.state
    if (!state) return null
    const slot = this.slots.activeSlot
    const render = this.renders[slot]
    if (!render) throw new Error('reforge: active dialogue observation is incomplete')
    return this.observeSlot(slot, render)
  }

  private observeSlot(slot: SlotId, render: SlotRender): DialogueObservation {
    const cue = render.cue
    const hasNextPage = render.pageStart + LINES_PER_PAGE < render.displayLines.length
    const pageTextIds: string[] = []
    for (const line of render.displayLines.slice(
      render.pageStart,
      render.pageStart + LINES_PER_PAGE,
    )) {
      const row = cue.rows[line.srcRowIdx]
      if (!row) throw new Error('reforge: dialogue page observation has no source row')
      if (!pageTextIds.includes(row.text)) pageTextIds.push(row.text)
    }
    return Object.freeze({
      dialogueId: render.dialogueId,
      cueIndex: render.cueIndex,
      slot,
      pageIndex: Math.floor(render.pageStart / LINES_PER_PAGE),
      pageCount: Math.max(1, Math.ceil(render.displayLines.length / LINES_PER_PAGE)),
      pageStartedAtMs: render.pageStartedAtMs,
      phase: !this.pageDone
        ? 'typing'
        : hasNextPage || render.autoAdvance === undefined
          ? 'waiting-input'
          : 'auto-advance',
      speaker: cue.speaker ?? null,
      rowTextIds: Object.freeze(cue.rows.map((row) => row.text)),
      pageTextIds: Object.freeze(pageTextIds),
      pageText: render.displayLines
        .slice(render.pageStart, render.pageStart + LINES_PER_PAGE)
        .map((line) => line.spans.map((span) => span.text).join(''))
        .join('\n'),
    })
  }

  /** 把第 idx 个 cue 排版进它的 slot。有头像时正文 x 缩进 + 右边界给头像让位。 */
  private layoutCueInto(cueIdx: number): { slot: SlotId; render: SlotRender } {
    const state = this.state
    if (!state) throw new Error('reforge: layoutCueInto has no dialogue')
    const cue = state.dialogue.cues[cueIdx]
    if (!cue) throw new Error('reforge: layoutCueInto cueIdx 越界')
    const slot: SlotId = cue.slot ?? 'bottom'
    const portraitImg = cue.portrait ? this.portraits.get(cue.portrait.asset) : undefined
    const hasPortrait = Boolean(portraitImg)
    const startX = hasPortrait ? POS[slot].textWithPortrait.x : POS[slot].text.x
    // D14-1:不再按头像收窄、不再扣光标预留;头像只改起点(startX 已处理)。
    // 光标按原版 posIcon 语义画在末行末尾,接近屏边时本就会被裁(视觉验收项)。
    const maxRight = this.framed ? (hasPortrait && slot === 'bottom' ? 232 : 304) : MAX_RIGHT
    const displayLines = layoutLines(
      cue.rows,
      this.glyphs,
      (textId) => lookupText(textId, this.locale),
      maxRight,
      startX,
    )
    const singleLineText = cue.rows.map((row) => lookupText(row.text, this.locale)).join('')
    return {
      slot,
      render: {
        cue,
        dialogueId: state.dialogue.id,
        cueIndex: cueIdx,
        presentationId: ++this.nextPresentationId,
        pageStartedAtMs: this.lineStartMs,
        visibleText: null,
        displayLines,
        singleLineSpans: parseRichText(singleLineText),
        pageStart: 0,
        rowSpeeds: cue.rows.map((row) =>
          slot === 'narration' ? 0 : (row.speed ?? DEFAULT_SPEED_MS),
        ),
        autoAdvance: cue.autoAdvance,
      },
    }
  }

  open(state: DialogueState, nowMs: number, lifetime: 'dialogue' | 'script' = 'dialogue'): void {
    const firstCue = state.dialogue.cues[0]
    if (!firstCue) throw new Error('reforge: 对话无显示单元')
    // Ordinary script commands share visible slots until explicit clearing. Narration
    // scrolls and standalone dialogues keep their own existing close-on-completion lifetime.
    this.retainSlots =
      lifetime === 'script' && (firstCue.slot === 'top' || (firstCue.slot ?? 'bottom') === 'bottom')
    this.state = state
    if (!this.retainSlots) {
      this.slots = emptySlots()
      this.renders = {}
    }
    this.lineStartMs = nowMs
    // 第一段话进它的 slot
    this.slots = advanceSlots(this.slots, firstCue, 0)
    const { slot, render } = this.layoutCueInto(0)
    this.renders[slot] = render
    this.pageDone = false
  }

  /**
   * 按 space(sdlpal fUserSkip 两段式 + slot 推进):
   * 1. 活跃槽未全显 → 瞬显该页。
   * 2. 活跃槽该段话还有下一页 → 翻该槽页。
   * 3. 该段话翻完 → 推进下一段话；脚本上下对白只结束等待，独立对话清所有。
   */
  advance(nowMs: number): void {
    if (!this.state) return
    if (!this.pageDone) {
      this.pageDone = true
      return
    }
    const active = this.slots.activeSlot
    const r = this.renders[active]
    if (r && r.pageStart + LINES_PER_PAGE < r.displayLines.length) {
      // 该段话还有下一页
      r.pageStart += LINES_PER_PAGE
      this.lineStartMs = nowMs
      r.pageStartedAtMs = nowMs
      r.visibleText = null
      this.pageDone = false
      return
    }
    // 该段话翻完 → 推进下一段话。但若该段有 autoAdvance(尾停顿),
    // sdlpal 真值(spec §Bug3):尾停顿不可加速,玩家按 space = noop,必须等 update 自动推进。
    if (this.activeAutoAdvance() !== undefined) return
    this.advanceToNextCue(nowMs)
  }

  /** 推进到下一个 cue；确认结束和可见槽清除有独立生命周期。 */
  private advanceToNextCue(nowMs: number): void {
    const cur = this.state
    if (!cur) return
    const next = advanceCue(cur)
    if (!next) {
      if (this.retainSlots) this.state = null
      else this.close()
      return
    }
    this.state = next
    const nextIdx = next.cueIdx
    const cue = next.dialogue.cues[nextIdx]
    if (!cue) throw new Error('reforge: advanceToNextCue cueIdx 越界')
    this.slots = advanceSlots(this.slots, cue, nextIdx)
    this.lineStartMs = nowMs
    const { slot, render } = this.layoutCueInto(nextIdx)
    this.renders[slot] = render // 同槽覆盖(替换 render)/异槽新建(旧 render 不动)
    this.pageDone = false
  }

  /** 关闭并清空 slot(正常收尾 + 脚本 abort/切场景清理共用)。 */
  close(): void {
    this.state = null
    this.slots = emptySlots()
    this.renders = {}
    this.retainSlots = false
  }

  /** 活跃槽当前段话的 autoAdvance(undefined = 无,等键)。 */
  private activeAutoAdvance(): number | undefined {
    return this.renders[this.slots.activeSlot]?.autoAdvance
  }

  /** autoAdvance:活跃槽该段话翻完 + 有 autoAdvance + 过尾停顿 → 自动推进下一段。 */
  private update(nowMs: number): void {
    if (!this.state || !this.pageDone) return
    const active = this.slots.activeSlot
    const r = this.renders[active]
    if (!r) return
    const auto = r.autoAdvance
    if (auto === undefined) return
    // 活跃段话整页打字耗时 + autoAdvanceMs(此 slot 该段话,逐显示行串行)
    const page = r.displayLines.slice(r.pageStart, r.pageStart + LINES_PER_PAGE)
    const typeMs = page.reduce(
      (sum, dl) => sum + countChars(dl.spans) * (r.rowSpeeds[dl.srcRowIdx] ?? DEFAULT_SPEED_MS),
      0,
    )
    if (nowMs - this.lineStartMs >= typeMs + auto) this.advanceToNextCue(nowMs)
  }

  render(nowMs: number): void {
    if (!this.visible) return
    // 画四个 slot；narration 走横向卷轴，center 才是无框居中大字。
    // narration 最后画 = 叠在最上层(原版 0x3E 中央窗;dlg.0 婶婶画外音、宝箱拾取旁白走此槽)。
    for (const slotId of ['bottom', 'top', 'narration', 'center'] as const) {
      const entry = this.slots[slotId]
      const r = this.renders[slotId]
      if (!entry || !r) continue
      const isActive = this.active && slotId === this.slots.activeSlot
      this.renderSlot(slotId, r, isActive, nowMs)
    }
    // 原索引帧是持久屏幕:~NN 到时只清对话状态，最后文字像素保留到下次重画。
    // 因此必须先画完本帧再自动推进；loadScene 紧随时才能捕获含文字的旧帧。
    this.update(nowMs)
  }

  /** 画单个 slot:姓名牌 + 正文(留显全字 / 活跃打字)+ 活跃槽的光标。 */
  private renderSlot(slotId: SlotId, r: SlotRender, isActive: boolean, nowMs: number): void {
    const pos = POS[slotId]
    const page = r.displayLines.slice(r.pageStart, r.pageStart + LINES_PER_PAGE)
    if (page.length === 0) return
    if (slotId === 'narration') {
      this.renderNarrationScroll(r, isActive)
      return
    }

    if (this.framed && (slotId === 'bottom' || slotId === 'top')) {
      const y = slotId === 'bottom' ? 102 : 2
      this.ctx.save()
      this.ctx.fillStyle = '#172630'
      this.ctx.fillRect(2, y, 316, 94)
      this.ctx.strokeStyle = '#b9a582'
      this.ctx.strokeRect(3.5, y + 1.5, 313, 91)
      this.ctx.restore()
    }
    // 该段话的头像(若有):spec §3 位置,bottom 右 / top 左。
    const cue = r.cue
    const hasPortrait = cue?.portrait ? this.portraits.has(cue.portrait.asset) : false
    const portraitImg = cue?.portrait ? this.portraits.get(cue.portrait.asset) : undefined
    if (hasPortrait && portraitImg) {
      const px = pos.portrait.x - portraitImg.width / 2
      const py = pos.portrait.y - portraitImg.height / 2
      this.ctx.drawImage(portraitImg, px, py)
    }
    // 正文 / 姓名 x:有头像时缩进(须与 layoutLineInto 的 startX 一致)
    const titleX = hasPortrait ? pos.titleWithPortrait.x : pos.title.x
    const textX = hasPortrait ? pos.textWithPortrait.x : pos.text.x

    // 姓名牌:该 slot 当前段话首行的 speaker(同段跨页常驻)
    if (cue?.speaker) {
      const nameSpans: TextSpan[] = [{ text: `${lookupText(cue.speaker, this.locale)}：` }]
      renderSpans(this.ctx, nameSpans, titleX, pos.title.y, {
        glyphs: this.glyphs,
        shadow: true,
        forceRgba: TITLE_RGBA,
      })
    }

    let ty = pos.text.y
    const elapsed = isActive ? nowMs - this.lineStartMs : Number.POSITIVE_INFINITY // 留显槽全字
    let elapsedBefore = 0
    let allDone = true
    const visibleLines: string[] = []
    for (const dl of page) {
      const rowLen = countChars(dl.spans)
      const speed = r.rowSpeeds[dl.srcRowIdx] ?? DEFAULT_SPEED_MS
      const limit = !isActive
        ? rowLen // 留显全字
        : this.pageDone
          ? rowLen // 瞬显全字
          : Math.min(charsShown(Math.max(0, elapsed - elapsedBefore), speed), rowLen)
      if (limit < rowLen) allDone = false
      renderSpans(this.ctx, dl.spans, textX, ty, {
        glyphs: this.glyphs,
        shadow: true,
        maxChars: limit,
        ...(this.framed ? { forceRgba: [239, 233, 213] as [number, number, number] } : {}),
      })
      visibleLines.push([...dl.spans.map((span) => span.text).join('')].slice(0, limit).join(''))
      elapsedBefore += rowLen * speed
      ty += LINE_HEIGHT
    }
    r.visibleText = visibleLines.join('\n')
    if (isActive && allDone && !this.pageDone) this.pageDone = true

    // 光标:仅普通上下对话槽 + 全显 + 非 autoAdvance。center 是无框剧情字幕，
    // 即使等键也不画箭头；narration 已在上方走专用卷轴并提前返回。
    const lastDl = page[page.length - 1]
    if (
      dialogSlotShowsCursor(slotId) &&
      isActive &&
      this.pageDone &&
      r.autoAdvance === undefined &&
      lastDl
    ) {
      this.drawCursor(
        nowMs,
        lastDl.spans,
        page.length - 1,
        { text: { x: textX, y: pos.text.y } },
        cue?.cursorFrame ?? 0,
      )
    }
  }

  /** 原版 kDialogCenterWindow：横向单行卷轴 + 全文瞬显，不画普通对话光标。 */
  private renderNarrationScroll(r: SlotRender, isActive: boolean): void {
    const text = r.singleLineSpans.map((span) => span.text).join('')
    if (!text) return
    const layout = narrationScrollLayout(text)
    if (this.scroll) {
      drawScroll(this.ctx, this.scroll, layout.boxX, layout.boxY, layout.boxLen, { shadow: false })
    }
    let x = layout.textX
    for (const span of r.singleLineSpans) {
      x += renderSpans(this.ctx, [span], x, layout.textY, {
        glyphs: this.glyphs,
        shadow: false,
        forceRgba: span.color ? colorRgba(span.color) : [0, 0, 0],
      })
    }
    if (isActive) this.pageDone = true
    r.visibleText = text
  }

  private drawCursor(
    nowMs: number,
    lastSpans: TextSpan[],
    lastRowIdx: number,
    pos: { text: { x: number; y: number } },
    frameIdx: 0 | 1 | 2,
  ): void {
    const frame = this.cursorFrames[frameIdx] ?? this.cursorFrames[0]
    if (!frame) return
    const step = Math.floor(nowMs / 100) % CURSOR_COLOR_COUNT
    const cacheKey = frameIdx * CURSOR_COLOR_COUNT + step // frame×6+step 唯一标识(3 frame × 6 色)
    const icon = this.cursorBaked[cacheKey] ?? this.bakeCursorStep(frame, cacheKey, step)
    const cursorX = pos.text.x + measureSpans(lastSpans, this.glyphs)
    const cursorY = pos.text.y + lastRowIdx * LINE_HEIGHT
    this.ctx.drawImage(icon, cursorX, cursorY)
  }

  private bakeCursorStep(frame: RleFrame, cacheKey: number, step: number): HTMLCanvasElement {
    // step 由 drawCursor 用 % CURSOR_COLOR_COUNT 计算得,恒落在 CURSOR_RGBA 范围内;
    // 此处显式判空(引擎 noNonNullAssertion,no `!`),越界兜底第 0 色。
    const rgba = CURSOR_RGBA[step] ?? CURSOR_RGBA[0]
    const baked = bakeCursorTinted(frame, rgba ?? [0, 0, 0])
    this.cursorBaked[cacheKey] = baked
    return baked
  }
}
