import { existsSync, readFileSync } from 'node:fs'
import { resolve } from 'node:path'
import type { CurrentManifest } from '@type-pal/content'
import {
  baselineWrites,
  type MigrationSnapshot,
  PAL_BASELINE_REL,
  serializeMigrationJson,
} from './migration-baseline.js'
import type { MigrationPlan } from './migration-plan.js'
import type { ProjectMigrationSnapshot } from './migration-project-io.js'
import type { TransactionChange, TransactionPrecondition } from './migration-transaction.js'
import type { PalAssetRetirement } from './pal-assets.js'

function differs(repo: string, path: string, content: string): boolean {
  const full = resolve(repo, path)
  return !existsSync(full) || readFileSync(full, 'utf8') !== content
}

/** 工程 target 与新纯 theirs baseline 的改动属于同一个可恢复事务。 */
export function buildMigrationTransactionChanges(args: {
  repo: string
  plan: Pick<MigrationPlan, 'writes' | 'deletes'>
  projectSnapshot: ProjectMigrationSnapshot
  previousBaseline?: MigrationSnapshot
  nextBaseline: MigrationSnapshot
  retiredAssets?: readonly PalAssetRetirement[]
  /** 必须最后提交：新 manifest 只能在资源及其 catalog 已就绪后对运行时可见。 */
  nextManifest?: CurrentManifest
  manifestPreconditions?: readonly TransactionPrecondition[]
}): TransactionChange[] {
  const { repo, plan, previousBaseline, nextBaseline, nextManifest } = args
  const changes: TransactionChange[] = []
  const plannedHash = (path: string): string | null => {
    const snapshot = args.projectSnapshot
    if (!snapshot.managedFiles.has(path)) throw new Error(`工程目标未纳入规划快照: ${path}`)
    const hash = snapshot.hashes.get(path)
    if (snapshot.files.has(path) !== (hash !== undefined))
      throw new Error(`工程规划快照缺原始字节 hash: ${path}`)
    return hash ?? null
  }
  const projectWriteOrder = (path: string): number => (path === 'content/scenes/index.json' ? 1 : 0)
  for (const [path, value] of [...plan.writes].sort(
    ([left], [right]) =>
      projectWriteOrder(left) - projectWriteOrder(right) || left.localeCompare(right),
  )) {
    changes.push({
      target: `projects/pal/${path}`,
      scope: 'project',
      content: serializeMigrationJson(value, path),
      expectedPreviousHash: plannedHash(path),
    })
  }
  for (const path of [...plan.deletes].sort()) {
    changes.push({
      target: `projects/pal/${path}`,
      scope: 'project',
      expectedPreviousHash: plannedHash(path),
    })
  }
  for (const retirement of [...(args.retiredAssets ?? [])].sort(
    (a, b) => a.path.localeCompare(b.path) || a.id.localeCompare(b.id),
  )) {
    if (
      retirement.path.includes('\\') ||
      retirement.path.split('/').some((part) => part === '' || part === '.' || part === '..') ||
      !retirement.path.startsWith('assets/migrated/') ||
      !/^[a-f0-9]{64}$/.test(retirement.expectedSha256)
    )
      throw new Error(`退役迁移资源计划无效: ${retirement.id} -> ${retirement.path}`)
    changes.push({
      target: `projects/pal/${retirement.path}`,
      scope: 'project',
      expectedPreviousHash: retirement.expectedSha256,
    })
  }

  if (new Set(changes.map((change) => change.target)).size !== changes.length)
    throw new Error('迁移写入计划包含重复工程目标')

  const desired = baselineWrites(nextBaseline)
  const statePath = `${PAL_BASELINE_REL}/_state.json`
  for (const [path, content] of [...desired]
    .filter(([path]) => path !== statePath)
    .sort(([a], [b]) => a.localeCompare(b))) {
    if (differs(repo, path, content)) changes.push({ target: path, scope: 'baseline', content })
  }
  for (const path of [...(previousBaseline?.managedFiles ?? [])].sort()) {
    if (nextBaseline.managedFiles.has(path)) continue
    const target = `${PAL_BASELINE_REL}/${path}`
    if (existsSync(resolve(repo, target))) changes.push({ target, scope: 'baseline' })
  }
  const state = desired.get(statePath)!
  if (differs(repo, statePath, state))
    changes.push({ target: statePath, scope: 'baseline', content: state })
  if (nextManifest) {
    if (!args.manifestPreconditions?.length) throw new Error('manifest 变更缺资源闭包前置条件')
    const path = 'projects/pal/manifest.json'
    const content = `${JSON.stringify(nextManifest, null, 2)}\n`
    if (differs(repo, path, content))
      changes.push({
        target: path,
        scope: 'manifest',
        content,
        preconditions: args.manifestPreconditions,
      })
  }
  return changes
}
