import { dirname, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import {
  type ActorDef,
  type AuthorSceneDef,
  type AuthorScriptLibrary,
  type ItemData,
  type ShopDef,
  type SpriteDef,
  validateAuthorSharedScripts,
  validateSceneIndex,
} from '@type-pal/content'
import { describe, expect, it } from 'vitest'
import { loadPalBaseline } from './migration-baseline.js'
import type { MigrationJson } from './migration-files.js'
import { createMigrationPlan, snapshotOf } from './migration-plan.js'
import { loadPalContentSupplySources } from './pal-content-supply-io.js'
import {
  buildPalCurrentPublication,
  validatePalCurrentPublication,
} from './pal-current-publication.js'
import { buildPalCurrentManifest } from './pal-manifest.js'

const repo = resolve(dirname(fileURLToPath(import.meta.url)), '../../..')

function jsonRecord(value: MigrationJson | undefined): Record<string, MigrationJson> {
  if (!value || typeof value !== 'object' || Array.isArray(value))
    throw new Error('expected publication JSON object')
  return value
}

function triggerSchemes(files: Map<string, MigrationJson>, path: string, entityId: string) {
  const entities = jsonRecord(files.get(path)).entities
  if (!Array.isArray(entities)) throw new Error('expected publication entity list')
  const entity = entities.find(
    (value) => value && typeof value === 'object' && !Array.isArray(value) && value.id === entityId,
  )
  return jsonRecord(jsonRecord(jsonRecord(entity).behaviors).trigger)
}

describe('PAL current-only publication', () => {
  it('publishes merged author scheme names without regenerating them, while rejecting broken item roots', () => {
    const baseline = loadPalBaseline(repo)!
    const baselineBefore = structuredClone(baseline)
    const sources = loadPalContentSupplySources(repo)
    const publication = buildPalCurrentPublication(baseline, sources)
    const publicationBefore = structuredClone(publication)
    const manifest = buildPalCurrentManifest(sources.assetCatalog)
    const authored = structuredClone(baseline)
    const names = [
      ['content/scenes/s001.json', 'e19', 'c8-74bc98f07f8e', '赠酒后：给钱托逍遥买鲜虾'],
      ['content/scenes/s003.json', 'e62', 'c8-321c0a7d7de1', '赠桂花酒：约定山神庙学剑'],
    ] as const
    for (const [path, entityId, id, label] of names)
      jsonRecord(triggerSchemes(authored.files, path, entityId)[id]).label = label
    const plan = createMigrationPlan(baseline, authored, publication)
    expect(plan.conflicts).toEqual([])
    const target = { ...publication, files: plan.target, managedFiles: new Set(plan.target.keys()) }
    for (const [path, entityId, id, label] of names)
      expect(jsonRecord(triggerSchemes(target.files, path, entityId)[id]).label).toBe(label)
    expect(() =>
      validatePalCurrentPublication({ publication: target, manifest, sources }),
    ).not.toThrow()
    const replay = createMigrationPlan(snapshotOf(publication), snapshotOf(target), publication)
    expect(replay.summary).toMatchObject({ writes: 0, deletes: 0, conflicts: 0 })
    expect(baseline).toEqual(baselineBefore)
    expect(publication).toEqual(publicationBefore)
    const invalid = structuredClone(target)
    delete triggerSchemes(invalid.files, names[0][0], names[0][1])[names[0][2]]
    expect(() =>
      validatePalCurrentPublication({ publication: invalid, manifest, sources }),
    ).toThrow('PAL 物品剧情方案悬空引用')
  })

  it('accepts merged author shop lifecycle and command changes, retaining the pure generated baseline', () => {
    const baseline = loadPalBaseline(repo)!
    const sources = loadPalContentSupplySources(repo)
    const publication = buildPalCurrentPublication(baseline, sources)
    const manifest = buildPalCurrentManifest(sources.assetCatalog)
    const authored = structuredClone(baseline)
    const shops = structuredClone(authored.files.get('content/shops.json')) as unknown as ShopDef[]
    const copied = { id: 21, items: [...shops[0]!.items].reverse().concat(shops[0]!.items[0]!) }
    authored.files.set('content/shops.json', [
      ...shops.filter(({ id }) => id !== 20),
      { id: 0, items: [] },
      copied,
    ] as never)
    let addedBuy = false
    function editCalls(value: unknown, clear: boolean): void {
      if (Array.isArray(value)) {
        const buy =
          !clear && !addedBuy
            ? value.find((entry) => entry?.kind === 'openShop' && entry.mode === 'buy')
            : undefined
        if (buy) {
          value.push(structuredClone(buy))
          addedBuy = true
        }
        value.forEach((entry) => editCalls(entry, clear))
      } else if (value && typeof value === 'object') {
        const record = value as Record<string, unknown>
        if (record.kind === 'openShop') {
          if (clear) record.mode = 'sell'
          if (record.mode === 'sell') record.shop = 999
          else if (record.shop === 20) record.shop = 21
        }
        Object.values(record).forEach((entry) => editCalls(entry, clear))
      }
    }
    for (const value of authored.files.values()) editCalls(value, false)
    expect(addedBuy).toBe(true)
    const plan = createMigrationPlan(baseline, authored, publication)
    expect(plan.conflicts).toEqual([])
    expect(plan.target.get('content/shops.json')).toEqual(authored.files.get('content/shops.json'))
    const target = { ...publication, files: plan.target, managedFiles: new Set(plan.target.keys()) }
    expect(() =>
      validatePalCurrentPublication({ publication: target, manifest, sources }),
    ).not.toThrow()
    const replay = createMigrationPlan(snapshotOf(publication), snapshotOf(target), publication)
    expect(replay.summary).toMatchObject({ writes: 0, deletes: 0, conflicts: 0 })
    expect(replay.target.get('content/shops.json')).toEqual(target.files.get('content/shops.json'))
    // The next publication consumes an authored baseline too, not a retired converter seed.
    // Added/duplicated command nodes and sell's inert shop field must survive that boundary.
    const rebasedPublication = buildPalCurrentPublication(snapshotOf(target), sources)
    for (const [path, value] of target.files)
      if (path.startsWith('content/scenes/'))
        expect(rebasedPublication.files.get(path)).toEqual(value)
    expect(
      (publication.files.get('content/shops.json') as unknown as ShopDef[]).map(({ id }) => id),
    ).toEqual(Array.from({ length: 20 }, (_, i) => i + 1))

    const dangling = { ...target, files: new Map(target.files) }
    dangling.files.set('content/shops.json', [{ id: 0, items: [] }] as never)
    expect(() =>
      validatePalCurrentPublication({ publication: dangling, manifest, sources }),
    ).toThrow(/商店 .*不在 shops/)
    const empty = structuredClone(target)
    empty.files.set('content/shops.json', [])
    for (const value of empty.files.values()) editCalls(value, true)
    expect(() =>
      validatePalCurrentPublication({ publication: empty, manifest, sources }),
    ).not.toThrow()
  })
  it('publishes the current baseline and raw-owned partitions directly as content22/SAVE12', () => {
    const baseline = loadPalBaseline(repo)
    expect(baseline).toBeDefined()
    const sources = loadPalContentSupplySources(repo)
    const staleItems = structuredClone(
      baseline!.files.get('content/items.json'),
    ) as unknown as ItemData[]
    const staleVessel = staleItems.find(({ id }) => id === '268')!
    staleVessel.desc = ['作者字段必须保留']
    staleVessel.buyPrice = 1_234
    const staleCraft = staleVessel.use!.effects.find((effect) => effect.kind === 'craftRecipe')!
    if (staleCraft.kind !== 'craftRecipe') throw new Error('expected craftRecipe')
    delete staleCraft.unavailableMessage
    const staleGourd = staleItems.find(({ id }) => id === '270')!
    staleGourd.desc = ['紫金葫芦作者字段必须保留']
    const stalePool = staleGourd.use!.effects.find(
      (effect) => effect.kind === 'drawFromResourcePool',
    )!
    if (stalePool.kind !== 'drawFromResourcePool') throw new Error('expected resource pool')
    delete stalePool.unavailableMessage
    const staleBaseline = { ...baseline!, files: new Map(baseline!.files) }
    staleBaseline.managedFiles = new Set(baseline!.managedFiles)
    staleBaseline.files.set('content/items.json', staleItems as never)
    const sceneIndex = validateSceneIndex(staleBaseline.files.get('content/scenes/index.json'))
    const authoredScene = sceneIndex.scenes[0]!
    const previousScenePath = authoredScene.path
    const authoredScenePath = 'content/authored/opening.json'
    authoredScene.name = '作者命名的开场'
    authoredScene.path = authoredScenePath
    staleBaseline.files.set('content/scenes/index.json', sceneIndex as never)
    staleBaseline.files.set(authoredScenePath, staleBaseline.files.get(previousScenePath)!)
    staleBaseline.files.delete(previousScenePath)
    staleBaseline.managedFiles.delete(previousScenePath)
    staleBaseline.managedFiles.add(authoredScenePath)
    const sceneBody = structuredClone(
      staleBaseline.files.get(authoredScenePath),
    ) as unknown as AuthorSceneDef
    const firstFlow = sceneBody.hooks!.onEnter!.variants.default!.flow
    if (firstFlow.kind !== 'stages') throw new Error('expected stage flow')
    firstFlow.stages[0]!.body.unshift({ kind: 'wait', ms: 27 })
    staleBaseline.files.set(authoredScenePath, sceneBody as never)
    const shared: AuthorScriptLibrary = {
      ...validateAuthorSharedScripts(staleBaseline.files.get('content/shared-scripts.json')),
      'shared/user/author-proof': {
        name: '作者共享正文',
        self: 'none',
        body: [{ kind: 'wait', ms: 19 }],
      },
    }
    staleBaseline.files.set('content/shared-scripts.json', shared as never)
    const customSprites = structuredClone(
      staleBaseline.files.get('content/sprites.json'),
    ) as unknown as SpriteDef[]
    const customSprite = {
      ...customSprites[0]!,
      id: 'author-proof-sprite',
      label: '作者自定义精灵',
    }
    customSprites.push(customSprite)
    staleBaseline.files.set('content/sprites.json', customSprites as never)
    const customActors = structuredClone(
      staleBaseline.files.get('content/actors.json'),
    ) as unknown as ActorDef[]
    const customActor = {
      ...customActors.at(-1)!,
      id: 'author-proof-actor',
      spriteId: customSprite.id,
    }
    customActors.push(customActor)
    staleBaseline.files.set('content/actors.json', customActors as never)
    const publication = buildPalCurrentPublication(staleBaseline, sources)
    const manifest = buildPalCurrentManifest(sources.assetCatalog)
    const report = validatePalCurrentPublication({ publication, manifest, sources })

    expect(report).toMatchObject({ scenes: 294, maps: 223, assets: 1_934 })
    const publishedSceneIndex = validateSceneIndex(
      publication.files.get('content/scenes/index.json'),
    )
    expect(publishedSceneIndex.scenes[0]).toEqual({
      id: authoredScene.id,
      name: '作者命名的开场',
      path: authoredScenePath,
    })
    expect(publication.files.has(authoredScenePath)).toBe(true)
    expect(publication.files.has(previousScenePath)).toBe(false)
    expect(publication.files.get(authoredScenePath)).toEqual(sceneBody)
    expect(publication.files.get('content/shared-scripts.json')).toEqual(shared)
    expect(
      (publication.files.get('content/sprites.json') as unknown as SpriteDef[]).find(
        ({ id }) => id === customSprite.id,
      ),
    ).toEqual(customSprite)
    const actors = publication.files.get('content/actors.json') as unknown as ActorDef[]
    expect(actors.map(({ id }) => id)).toEqual([
      'li-xiaoyao',
      'zhao-linger',
      'lin-yueru',
      'wu-hou',
      'anu',
      'gai-luojiao',
      'jiu-jianxian',
      'li-daniang',
      'author-proof-actor',
    ])
    expect(actors.find(({ id }) => id === customActor.id)).toEqual(customActor)
    const gai = actors.find(({ id }) => id === 'gai-luojiao')!
    expect(gai.portraits).toEqual({ default: 'portrait.pal.044' })
    expect(gai).not.toHaveProperty('face')
    const faceRecords = Object.values(sources.assetCatalog.assets).filter(
      (record) => record.kind === 'face',
    )
    expect(faceRecords).toHaveLength(5)
    expect(faceRecords.reduce((total, record) => total + record.bytes, 0)).toBe(10_324)
    expect(actors.filter(({ face }) => face !== undefined)).toHaveLength(5)
    expect(
      actors.every(
        ({ face }) => face === undefined || sources.assetCatalog.assets[face]?.kind === 'face',
      ),
    ).toBe(true)
    expect(sources.assetCatalog.assets).not.toHaveProperty('face.pal.gai-luojiao')
    expect(sources.binaryAssets.some(({ id }) => id === 'face.pal.gai-luojiao')).toBe(false)
    expect(manifest).not.toHaveProperty('migrations')
    expect(manifest).not.toHaveProperty('entryScene')
    expect(manifest).not.toHaveProperty('startWorld')
    expect(manifest.assets).not.toHaveProperty('legacy')
    expect([...publication.managedFiles]).not.toContain('content/migrations/script-v4-v5-save.json')
    expect([...publication.managedFiles].some((path) => path.startsWith('_transitions/'))).toBe(
      false,
    )
    const items = publication.files.get('content/items.json') as unknown as ItemData[]
    const vessel = items.find(({ id }) => id === '268')!
    const craft = vessel.use!.effects.find((effect) => effect.kind === 'craftRecipe')!
    expect(vessel.desc).toEqual(['作者字段必须保留'])
    expect(vessel.buyPrice).toBe(1_234)
    expect(craft).toMatchObject({ unavailableMessage: '炼蛊的材料不足' })
    const gourd = items.find(({ id }) => id === '270')!
    const pool = gourd.use!.effects.find((effect) => effect.kind === 'drawFromResourcePool')!
    expect(gourd.desc).toEqual(['紫金葫芦作者字段必须保留'])
    expect(pool).toMatchObject({ unavailableMessage: '无任何效果' })
    const shops = publication.files.get('content/shops.json') as unknown as ShopDef[]
    expect(shops.map(({ id }) => id)).toEqual(Array.from({ length: 20 }, (_, index) => index + 1))
    expect(shops.some(({ id }) => id === 0)).toBe(false)
  })

  it('rejects invalid poison definitions before publishing a current project', () => {
    const baseline = loadPalBaseline(repo)
    expect(baseline).toBeDefined()
    const sources = loadPalContentSupplySources(repo)
    const publication = buildPalCurrentPublication(baseline!, sources)
    const manifest = buildPalCurrentManifest(sources.assetCatalog)
    const poisonsPath = manifest.content.poisons!
    const poisons = publication.files.get(poisonsPath)
    if (!Array.isArray(poisons) || poisons.length === 0)
      throw new Error(`${poisonsPath}: 期望非空毒定义数组`)
    const firstPoison = poisons[0]!
    const invalidPublication = {
      ...publication,
      files: new Map(publication.files),
    }
    invalidPublication.files.set(poisonsPath, [...poisons, structuredClone(firstPoison)])

    expect(() =>
      validatePalCurrentPublication({ publication: invalidPublication, manifest, sources }),
    ).toThrow(/poisons\[\d+\]\.id: 毒 \d+ 重复/)
  })
})
