import type {
  AmbienceDef,
  CurrentManifest,
  EnemyTeamDef,
  ItemData,
  MigrationDiagnosticsV1,
  RuntimeSceneDef,
  SceneIndexV1,
} from '@type-pal/content'
import {
  CONTENT_VERSION,
  CURRENT_PROJECT_MINIMUM_SAVE_VERSION,
  collectAssetReferences,
  mapAssetById,
  resolveAuthorDialogueTree,
  sceneAssetById,
  validateActors,
  validateAssetCatalog,
  validateAssetReferenceClosure,
  validateAuthorDialogueReferences,
  validateAuthorEnemies,
  validateAuthorItems,
  validateAuthorScenes,
  validateAuthorSharedScripts,
  validateBattleFields,
  validateBattleSprites,
  validateCurrentManifestStartup,
  validateEnemyTeams,
  validateEquipBattleSpriteReferences,
  validateLocale,
  validateManifestAssetConfig,
  validateMapIndex,
  validateMigrationDiagnostics,
  validatePoisons,
  validateProjectMap,
  validateReferences,
  validateSceneIndex,
  validateShops,
  validateSkills,
  validateSprites,
  validateStampTemplates,
  validateTilesets,
  validateWorldVariableRegistryV1,
} from '@type-pal/content'
import type { MigrationSnapshot } from './migration-baseline.js'
import type { MigrationJson } from './migration-files.js'
import type { TransactionPrecondition } from './migration-transaction.js'
import { applyPalItemOverlays } from './pal-authored-overlays.js'
import { buildPalContentSupply, type PalContentSupplySources } from './pal-content-supply.js'
import { assertPalInPartyActorIdInvariant } from './pal-inparty-actor-id-invariant.js'
import { applyPalItemMessageSources } from './pal-item-message-source.js'
import { inspectPalItemSchemeRoots } from './pal-item-scheme-labels.js'
import { assertPalSceneIndexOwnership } from './pal-scene-index.js'
import {
  assertPalAlchemyBoundaryInvariant,
  assertPalStoreBoundaryInvariant,
} from './pal-store-boundary.js'
import { PAL_WORLD_SCENE_SEMANTIC_SPRITE_ALIASES } from './pal-world-sprite-layouts.js'
import { applyPalWorldSpriteSemanticAliases } from './pal-world-sprite-semantic-alias.js'
import type { ProjectMapAuditReport } from './project-map-audit.js'

export interface PalCurrentPublication {
  files: Map<string, MigrationJson>
  managedFiles: Set<string>
  mapReport: ProjectMapAuditReport
}

export interface PalCurrentPublicationValidation {
  scenes: number
  maps: number
  assets: number
  managedFiles: number
  referenceWarnings: number
  assetWarnings: number
}

const FORBIDDEN_CURRENT_PATH = /^(?:_transitions\/|content\/migrations\/|content\/scripts\/)/
function asJson(value: unknown): MigrationJson {
  return JSON.parse(JSON.stringify(value)) as MigrationJson
}

function required(files: ReadonlyMap<string, MigrationJson>, path: string): unknown {
  if (!files.has(path)) throw new Error(`PAL current publication 缺文件 ${path}`)
  return files.get(path)
}

function requiredPath(path: string | undefined, label: string): string {
  if (!path) throw new Error(`PAL current manifest 缺 ${label} 路径`)
  return path
}

/**
 * 唯一发布模型：作者内容以 current baseline 为三方合并 base；可重建的 catalog、
 * PAL 六名原始角色、地图和瓦片集每次直接从窄供应核取值。角色分区
 * 按 stable id 替换，baseline 中不属于 PAL 原始六角色的作者角色保留。
 */
export function buildPalCurrentPublication(
  baseline: MigrationSnapshot,
  sources: PalContentSupplySources,
): PalCurrentPublication {
  const forbidden = [...baseline.managedFiles].filter((path) => FORBIDDEN_CURRENT_PATH.test(path))
  if (forbidden.length)
    throw new Error(`current baseline 含历史发布路径: ${forbidden.slice(0, 10).join(', ')}`)

  const files = new Map(baseline.files)
  const managedFiles = new Set(baseline.managedFiles)
  const generated = buildPalContentSupply(sources)
  const previousMapPaths = [...managedFiles].filter((path) =>
    /^content\/maps\/(?!index\.json$)[^/]+\.json$/.test(path),
  )
  for (const path of previousMapPaths) {
    managedFiles.delete(path)
    files.delete(path)
  }

  const put = (path: string, value: unknown): void => {
    files.set(path, asJson(value))
    managedFiles.add(path)
  }
  const baselineActors = validateActors(required(files, 'content/actors.json'))
  const generatedActors = validateActors(required(generated.files, 'content/actors.json'))
  const generatedActorIds = new Set(generatedActors.map(({ id }) => id))
  if (generatedActorIds.size !== sources.migrate.roles.length)
    throw new Error(
      `PAL 原始角色分区数量漂移: actors=${generatedActorIds.size} roles=${sources.migrate.roles.length}`,
    )
  const authoredActors = baselineActors.filter(({ id }) => !generatedActorIds.has(id))

  const currentSprites = validateSprites(required(files, 'content/sprites.json'))
  const generatedSprites = generated.roleDefinitions
  const sceneSurface = (source: ReadonlyMap<string, MigrationJson>, label: string) => {
    const index = validateSceneIndex(required(source, 'content/scenes/index.json'))
    return {
      index,
      values: index.scenes.map((entry) => {
        try {
          return required(source, entry.path)
        } catch (cause) {
          throw new Error(`${label}: SceneIndex ${entry.id} 缺正文 ${entry.path}`, { cause })
        }
      }),
    }
  }
  const currentSceneSurface = sceneSurface(files, 'PAL current baseline')
  assertPalSceneIndexOwnership({
    current: currentSceneSurface.index,
    generated: generated.sceneIndex,
  })
  const currentScenes = validateAuthorScenes(currentSceneSurface.values)
  const spriteAliases = applyPalWorldSpriteSemanticAliases({
    currentSprites,
    generatedSprites,
    currentScenes: new Map(currentScenes.map((scene) => [scene.id, scene])),
    generatedScenes: new Map(generated.scenes.map((scene) => [scene.id, scene])),
    roleSpritesByNumber: generated.roleSpritesByNumber,
    aliases: PAL_WORLD_SCENE_SEMANTIC_SPRITE_ALIASES,
  })

  put('assets/index.json', required(generated.files, 'assets/index.json'))
  put('content/actors.json', [...generatedActors, ...authoredActors])
  const baselineItems = required(files, 'content/items.json')
  if (!Array.isArray(baselineItems))
    throw new Error('PAL current baseline: content/items.json 期望数组')
  put(
    'content/items.json',
    applyPalItemMessageSources(
      applyPalItemOverlays(baselineItems as ItemData[]),
      generated.itemMessages,
    ),
  )
  put('content/shops.json', required(generated.files, 'content/shops.json'))
  put('content/sprites.json', spriteAliases.sprites)
  for (const [sceneId, scene] of spriteAliases.updatedScenes) {
    const asset = sceneAssetById(currentSceneSurface.index, sceneId)
    if (!asset) throw new Error(`PAL current SceneIndex 缺更新目标 ${sceneId}`)
    put(asset.path, scene)
  }
  put('content/maps/index.json', required(generated.files, 'content/maps/index.json'))
  put('content/tilesets.json', required(generated.files, 'content/tilesets.json'))
  const generatedMapPaths = [...generated.managedFiles]
    .filter((path) => /^content\/maps\/(?!index\.json$)[^/]+\.json$/.test(path))
    .sort()
  if (generatedMapPaths.length !== sources.tilemaps.length)
    throw new Error(
      `PAL 地图分区数量漂移: files=${generatedMapPaths.length} sources=${sources.tilemaps.length}`,
    )
  for (const path of generatedMapPaths) put(path, required(generated.files, path))

  // Shop inventory and alchemy remain source-owned. Script bodies come from the authored
  // current baseline: restructuring branches may change the number of openShop nodes.
  // The source seed has only raw-owned shops; authored references must be checked against
  // the merged directory in validatePalCurrentPublication, after author overrides are applied.
  assertPalStoreBoundaryInvariant({
    sourceStores: sources.stores,
    shops: validateShops(required(files, 'content/shops.json')),
    items: validateAuthorItems(required(files, 'content/items.json')),
    commandRoots: [],
  })
  return { files, managedFiles, mapReport: generated.mapReport }
}

/** current canonical 内容的内存发布门；在资源写入和事务 journal 创建之前执行。 */
export function validatePalCurrentPublication(args: {
  publication: PalCurrentPublication
  manifest: CurrentManifest
  sources: PalContentSupplySources
}): PalCurrentPublicationValidation {
  const { files, managedFiles } = args.publication
  const { manifest } = args
  if (
    manifest.contentVersion !== CONTENT_VERSION ||
    manifest.minimumSaveVersion !== CURRENT_PROJECT_MINIMUM_SAVE_VERSION
  )
    throw new Error(
      `PAL current publication 只接受 content${CONTENT_VERSION} / SAVE${CURRENT_PROJECT_MINIMUM_SAVE_VERSION}`,
    )
  validateCurrentManifestStartup(manifest)
  if ('migrations' in manifest || manifest.content.scripts !== undefined)
    throw new Error('PAL current manifest 禁止 migrations/content.scripts')
  const forbidden = [...managedFiles].filter((path) => FORBIDDEN_CURRENT_PATH.test(path))
  if (forbidden.length)
    throw new Error(`PAL current publication 含历史路径 ${forbidden.join(', ')}`)

  const catalog = validateAssetCatalog(required(files, manifest.assets.catalog))
  validateManifestAssetConfig(manifest.assets, catalog)
  const actors = validateActors(required(files, requiredPath(manifest.content.actors, 'actors')))
  const actorsById = Object.fromEntries(actors.map((actor) => [actor.id, actor]))
  const skills = validateSkills(required(files, requiredPath(manifest.content.skills, 'skills')))
  const authorItems = validateAuthorItems(
    required(files, requiredPath(manifest.content.items, 'items')),
  )
  const authorEnemies = validateAuthorEnemies(
    required(files, requiredPath(manifest.content.enemies, 'enemies')),
  )
  const locale = validateLocale(required(files, requiredPath(manifest.content.locale, 'locale')), {
    allowSoftWrap: true,
  })
  const sprites = validateSprites(
    required(files, requiredPath(manifest.content.sprites, 'sprites')),
    catalog,
  )
  const battleSprites = validateBattleSprites(
    required(files, requiredPath(manifest.content.battleSprites, 'battleSprites')),
    catalog,
  )
  const battleFields = validateBattleFields(
    required(files, requiredPath(manifest.content.battleFields, 'battleFields')),
  )
  const enemyTeams = validateEnemyTeams(
    required(files, requiredPath(manifest.content.enemyTeams, 'enemyTeams')),
    new Set(authorEnemies.map((enemy) => enemy.id)),
  )
  const tilesets = validateTilesets(
    required(files, requiredPath(manifest.content.tilesets, 'tilesets')),
    catalog,
  )
  const tilesetIds = new Set(tilesets.map((tileset) => tileset.id))
  const stamps = validateStampTemplates(
    required(files, requiredPath(manifest.content.stamps, 'stamps')),
  )
  for (const stamp of stamps)
    for (const tileset of stamp.tilesetRefs)
      if (!tilesetIds.has(tileset)) throw new Error(`组合 ${stamp.id} 引用未知瓦片集 ${tileset}`)
  const mapIndex = validateMapIndex(required(files, requiredPath(manifest.content.maps, 'maps')))
  if (mapIndex.maps.length !== args.sources.tilemaps.length)
    throw new Error(
      `PAL current 地图数量 ${mapIndex.maps.length} != 源 ${args.sources.tilemaps.length}`,
    )
  for (const entry of mapIndex.maps) {
    const map = validateProjectMap(required(files, entry.path))
    for (const tileset of map.tilesetRefs)
      if (!tilesetIds.has(tileset)) throw new Error(`${entry.path} 引用未知瓦片集 ${tileset}`)
  }

  const scenesDir = `${requiredPath(manifest.content.scenes, 'scenes').replace(/\/?$/, '/')}`
  const sceneIndexPath = `${scenesDir}index.json`
  const sceneIndex: SceneIndexV1 = validateSceneIndex(
    required(files, sceneIndexPath),
    sceneIndexPath,
  )
  const sceneIds = sceneIndex.scenes.map((entry) => entry.id)
  validateCurrentManifestStartup(manifest, sceneIds)
  const authorScenes = validateAuthorScenes(
    sceneIndex.scenes.map((entry) => required(files, entry.path)),
  )
  authorScenes.forEach((scene, index) => {
    if (scene.id !== sceneIndex.scenes[index]?.id)
      throw new Error(`场景 index/id 不符 ${String(sceneIndex.scenes[index]?.id)}`)
    if (!mapAssetById(mapIndex, scene.mapId))
      throw new Error(`场景 ${scene.id} 引用未知地图 ${scene.mapId}`)
  })
  inspectPalItemSchemeRoots({
    items: authorItems,
    scenes: authorScenes,
    expectedSchemes: 49,
    expectedItemRoots: 11,
  })
  const sharedScripts = validateAuthorSharedScripts(
    required(files, requiredPath(manifest.content.sharedScripts, 'sharedScripts')),
  )
  assertPalInPartyActorIdInvariant({
    actors,
    commandRoots: [authorScenes, authorItems, authorEnemies, sharedScripts],
  })
  validateAuthorDialogueReferences({
    scenes: authorScenes,
    items: authorItems,
    sharedScripts,
    enemies: authorEnemies,
    actors,
  })
  const scenes = resolveAuthorDialogueTree(authorScenes, actorsById, 'scenes') as RuntimeSceneDef[]
  const items = resolveAuthorDialogueTree(authorItems, actorsById, 'items')
  const enemies = resolveAuthorDialogueTree(authorEnemies, actorsById, 'enemies')
  const runtimeSharedScripts = resolveAuthorDialogueTree(sharedScripts, actorsById, 'sharedScripts')
  const equipIssues = validateEquipBattleSpriteReferences(items, actors, battleSprites)
  if (equipIssues.length) throw new Error(`${equipIssues[0]!.where}: ${equipIssues[0]!.message}`)
  const poisons = validatePoisons(
    required(files, requiredPath(manifest.content.poisons, 'poisons')),
  )
  const shops = validateShops(required(files, requiredPath(manifest.content.shops, 'shops')))
  const ambiences = required(
    files,
    requiredPath(manifest.content.ambiences, 'ambiences'),
  ) as AmbienceDef[]
  const migrationDiagnostics = validateMigrationDiagnostics(
    required(files, requiredPath(manifest.content.migrationDiagnostics, 'migrationDiagnostics')),
  ) as MigrationDiagnosticsV1
  validateWorldVariableRegistryV1(
    required(files, requiredPath(manifest.content.worldVariables, 'worldVariables')),
  )
  assertPalAlchemyBoundaryInvariant({
    sourceStores: args.sources.stores,
    items: authorItems,
  })
  const referenceIssues = validateReferences({
    scenes: scenes as never,
    actors,
    skills: skills.skills,
    levelUp: skills.levelUp as never,
    items,
    locale,
    sprites,
    battleSprites,
    entryPoints: manifest.entryPoints,
    enemies: enemies as never,
    enemyTeams: enemyTeams as EnemyTeamDef[],
    battleFields,
    poisons,
    ambiences,
    shops,
    tilesets,
    stamps,
    mapIndex,
    sharedScripts: runtimeSharedScripts as never,
    migrationDiagnostics,
  })
  const referenceErrors = referenceIssues.filter((issue) => issue.severity === 'error')
  if (referenceErrors.length)
    throw new Error(
      `PAL current 跨引用失败:\n${referenceErrors
        .slice(0, 50)
        .map((issue) => `${issue.where}: ${issue.message}`)
        .join('\n')}`,
    )
  const assetIssues = validateAssetReferenceClosure(
    catalog,
    collectAssetReferences({
      assets: manifest.assets,
      entryPoints: manifest.entryPoints,
      scenes: scenes as never,
      sharedScripts: runtimeSharedScripts,
      actors,
      enemies: enemies as never,
      items: items as never,
      skills: skills.skills,
      battleFields,
      tilesets,
      sprites,
      battleSprites,
    }),
  )
  const assetErrors = assetIssues.filter((issue) => issue.severity === 'error')
  if (assetErrors.length)
    throw new Error(
      `PAL current 资源闭包失败:\n${assetErrors
        .slice(0, 50)
        .map((issue) => `${issue.where}: ${issue.message}`)
        .join('\n')}`,
    )
  return {
    scenes: authorScenes.length,
    maps: mapIndex.maps.length,
    assets: Object.keys(catalog.assets).length,
    managedFiles: managedFiles.size,
    referenceWarnings: referenceIssues.length,
    assetWarnings: assetIssues.length,
  }
}

/** manifest 是事务最后一项；每个 catalog 二进制必须先按目标 hash 物化。 */
export function palAssetPreconditions(
  publication: PalCurrentPublication,
): TransactionPrecondition[] {
  const catalog = validateAssetCatalog(required(publication.files, 'assets/index.json'))
  return Object.values(catalog.assets)
    .map((record) => ({ target: `projects/pal/${record.path}`, hash: record.sha256 }))
    .sort((left, right) => left.target.localeCompare(right.target))
}
