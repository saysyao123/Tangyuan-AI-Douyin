/**
 * events.json schema(见 docs/phase1/05-events-schema.md)。
 * M1 提供 ~10 个 M2 切片要用的具名 Command + raw 兜底 + 结构化子集(D17,新内容手写用)。
 */

export interface RawCommand {
  op: 'raw'
  opcode: number
  operands: [number, number, number]
  label?: string
}

export interface EndCommand {
  op: 'end'
  advance?: boolean
  reset?: boolean
  /** 仅 reset=true 时有效:重置后跳转到的指令下标(原 operand[0]) */
  resetTo?: number
  /** 仅 reset=true 时有效:重置前等待帧数(原 operand[1]) */
  idleFrames?: number
  label?: string
}

export interface GotoCommand {
  op: 'goto'
  to: string // 跳转目标标签名;跨文件用 "shared#L_X" / "objects#L_X"
  frameDelay?: number
  label?: string
}

/** 对话框样式 —— 由前置 opcode 0x003B-0x003E 设置(M2 新具名,见 D26)。
 *  注:M2 设计文档原把此类型归在 resources.ts,但因被 SetDialogStyleCommand
 *  + ShowDialogCommand.box 直接使用,实施时提前放在 events.ts。Task 2 实施
 *  resources.ts 时无需重复定义。
 */
// 'item-box' = L1 紫金葫芦炼丹物品框(opcode 0x34 / SPRITENUM_ITEMBOX,script.c:1480-1512):
//   屏幕居中 ITEMBOX 精灵 + 物品 BALL 图标 + 2 行居中文字,复用 narration 1.4s 自动关时序。
export type DialogBoxStyle = 'top' | 'center' | 'bottom' | 'narration' | 'item-box'

export interface ShowDialogCommand {
  op: 'showDialog'
  /** 对话框样式;由 0x003B-0x003E 设置,disasm 不产出此字段 */
  box?: DialogBoxStyle
  /** M.MSG 中的消息下标(原 operand[0]),round-trip 必须原样写回 */
  messageIndex: number
  /** 内联自 M.MSG 的可读文本;仅供人工阅读,recompile 不使用 */
  text: string
  label?: string
}

export interface GiveItemCommand {
  op: 'giveItem'
  itemId: number
  count: number
  _item?: string
  label?: string
}

export interface StartBattleCommand {
  op: 'startBattle'
  enemyTeamId: number
  /**
   * P0.e:opcode 7 raw operands `[enemyTeamId, onLoseScript, onFleeScript]`
   * 完整透传(disassembler 升级具名时填)— event-system 用 operand[2] 算 isBoss
   * (sdlpal script.c:3318 `!operand[2]`)。
   */
  operands?: [number, number, number]
  _enemyTeam?: string
  label?: string
}

/** Scene 切换命令 —— 对应 sdlpal opcode 0x0059(script.c:1870 "Change to the specified scene")。
 *  字节布局:operand[0] = sceneId(目标场景号);operand[1] / [2] sdlpal 该 case 未读。
 *
 *  **运行时语义**:M3.5 内 EventSystem handler 是 stub(no-op skip + console.debug);
 *  真 scene 切换通过 dev panel 直调 `loadScene()` 函数实现(D34/B 路线)。M5 真做剧情链时
 *  升级 handler 为可等待命令(emit + Shell 处理 async loadScene + complete cmdId)。
 */
export interface LoadSceneCommand {
  op: 'loadScene'
  sceneId: number
  /** annotate 注入的人读场景名(symbols.json.scene[sceneId])—— 仅供阅读,recompile 不用 */
  _scene?: string
  label?: string
}

/**
 * 对话框样式 setter —— 对应 sdlpal 的 PAL_StartDialog 4 种 box 模式
 * (0x003B kDialogCenter / 0x003C kDialogUpper / 0x003D kDialogLower /
 *  0x003E kDialogCenterWindow;见 reference/sdlpal/script.c:3389-3426)。
 *
 * arg0/arg1/arg2 = 原始 operand 三元组,**仅**用于字节级 round-trip;
 * 各 operand 语义见上述 script.c 区段。M2 EventSystem 不读这些字段,
 * 留待 M5+ 真有消费者时再做具名解析(避免现在锁定可能错的字段名)。
 */
export interface SetDialogStyleTopCommand {
  op: 'setDialogStyleTop'
  arg0?: number
  arg1?: number
  arg2?: number
  label?: string
}

export interface SetDialogStyleCenterCommand {
  op: 'setDialogStyleCenter'
  arg0?: number
  arg1?: number
  arg2?: number
  label?: string
}

export interface SetDialogStyleBottomCommand {
  op: 'setDialogStyleBottom'
  arg0?: number
  arg1?: number
  arg2?: number
  label?: string
}

export interface SetDialogStyleNarrationCommand {
  op: 'setDialogStyleNarration'
  arg0?: number
  arg1?: number
  arg2?: number
  label?: string
}

// 结构化子集(D17)—— 反汇编器不产出,新内容手写用
export interface SequenceCommand {
  op: 'sequence'
  steps: Command[]
  label?: string
}

export interface IfCommand {
  op: 'if'
  cond: Command
  then: Command[]
  else?: Command[]
  label?: string
}

export interface ChoiceCommand {
  op: 'choice'
  prompt: string
  options: { text: string; then: Command[] }[]
  label?: string
}

/** 切换调色板命令 —— 对应 sdlpal opcode 0x008B(script.c:2571 "change the current palette")。
 *  字节布局:operand[0] = paletteIndex;operand[1] / [2] sdlpal 该 case 未读。
 *
 *  **运行时语义**:EventSystem handler 调 fetchPalette(paletteIndex) 后更新 gs.palette,
 *  渲染层下一帧 flushToCanvas 自动使用新调色板。
 */
export interface SetPaletteCommand {
  op: 'setPalette'
  paletteIndex: number
  label?: string
}

export type Command =
  | RawCommand
  | EndCommand
  | GotoCommand
  | ShowDialogCommand
  | GiveItemCommand
  | StartBattleCommand
  | LoadSceneCommand
  | SetPaletteCommand
  | SetDialogStyleTopCommand
  | SetDialogStyleCenterCommand
  | SetDialogStyleBottomCommand
  | SetDialogStyleNarrationCommand
  | SequenceCommand
  | IfCommand
  | ChoiceCommand

export interface EventFile {
  /** 场景号;只有 scene-NNN.json 有,shared.json / objects.json 不带 */
  scene?: number
  segments: EventSegment[]
}

export interface EventSegment {
  /**
   * 段名 —— 描述这段从哪入口可达:
   *   "scene-NNN.onEnter" / "object-MM.trigger" / "object-MM.auto" …
   */
  name: string
  commands: Command[]
}
