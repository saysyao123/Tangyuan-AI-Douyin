import { describe, expect, test } from 'vitest'
import type { ActorDef } from './actor.js'
import { applyActorCondition } from './actor-condition.js'
import {
  applySetParty,
  buildWorld,
  instantiate,
  type StartWorld,
  type WorldState,
} from './character.js'
import type { PoisonDef } from './poison.js'

// 内联角色 fixture(C0:CharacterTemplate → ActorDef,battler 包住战斗数据)
const hero: ActorDef = {
  id: 'test-hero',
  name: 'name.test-hero',
  spriteId: 'hero-sprite',
  battler: {
    battleSprite: 'hero-battle-sprite',
    baseStats: {
      level: 1,
      hp: 150,
      maxHP: 150,
      mp: 100,
      maxMP: 100,
      attack: 33,
      defense: 32,
      magicAttack: 20,
      speed: 28,
      luck: 32,
    },
    initialEquipment: { weapon: '166', accessory: '249' },
    initialMagic: ['296'],
  },
}

/** 无 battler 的普通 NPC(不可入队)。 */
const villager: ActorDef = { id: 'villager', name: 'name.villager', spriteId: 'ghost' }

const poisons: Record<number, PoisonDef> = {
  551: { id: 551, name: '赤毒', curability: 'common', color: 16 },
  555: { id: 555, name: '三尸蛊', curability: 'severe', color: 0 },
}

describe('角色 schema(ActorDef)', () => {
  test('instantiate 角色 → 实例(读 battler;初始值拷贝;exp=0,tags 空)', () => {
    const inst = instantiate(hero)
    expect(inst.id).toBe('test-hero')
    expect(inst.template).toBe('test-hero')
    expect(inst.level).toBe(1)
    expect(inst.hp).toBe(150)
    expect(inst.maxHP).toBe(150)
    expect(inst.mp).toBe(100)
    expect(inst.attack).toBe(33)
    expect(inst.exp).toBe(0)
    expect(inst.equipment).toEqual({ weapon: '166', accessory: '249' })
    expect(inst.tags).toEqual([])
  })
  test('instantiate 每次独立(不共享引用)', () => {
    const a = instantiate(hero)
    const b = instantiate(hero)
    a.hp = 1
    expect(b.hp).toBe(150) // 不串
    a.equipment.weapon = '999'
    expect(b.equipment.weapon).toBe('166') // equipment 深拷贝
  })
  test('无 battler 的 actor → instantiate throw(含 id)', () => {
    expect(() => instantiate(villager)).toThrow(/villager.*battler/)
  })
})

describe('buildWorld(入口 startWorld 数据化)', () => {
  test('组装:party instantiate + seedStats 覆盖当前 hp/mp + 角色定义播种技能', () => {
    const sw: StartWorld = {
      party: ['test-hero'],
      money: 50,
      inventory: [{ itemId: '267', count: 1 }],
      seedStats: { 'test-hero': { hp: 100, mp: 30 } },
    }
    const w = buildWorld(sw, { 'test-hero': hero })
    expect(w.money).toBe(50)
    expect(w.party).toHaveLength(1)
    expect(w.party[0]?.id).toBe('test-hero')
    expect(w.party[0]?.hp).toBe(100) // seedStats 覆盖(模板 150 → 100)
    expect(w.party[0]?.mp).toBe(30) // seedStats 覆盖(模板 100 → 30)
    expect(w.party[0]?.maxHP).toBe(150) // maxHP 不被 seedStats 动
    expect(w.party[0]?.maxMP).toBe(100) // maxMP 不被 seedStats 动
    expect(w.learnedSkills['test-hero']).toEqual(['296'])
    expect(w.inventory).toEqual([{ itemId: '267', count: 1 }])
  })
  test('运行时技能深拷贝，学习或遗忘不回写角色定义', () => {
    const w = buildWorld({ party: ['test-hero'], money: 0, inventory: [] }, { 'test-hero': hero })
    w.learnedSkills['test-hero']!.push('298')
    expect(hero.battler?.initialMagic).toEqual(['296'])
  })
  test('无 seedStats → 用 battler.baseStats 的 hp/mp', () => {
    const sw: StartWorld = { party: ['test-hero'], money: 0, inventory: [] }
    const w = buildWorld(sw, { 'test-hero': hero })
    expect(w.party[0]?.hp).toBe(150)
    expect(w.party[0]?.mp).toBe(100)
  })
  test('只在新建世界时为开局队员播种三种 condition carrier', () => {
    const sw: StartWorld = {
      party: ['test-hero'],
      money: 0,
      inventory: [],
      seedConditions: {
        'test-hero': {
          poisonIds: [551, 555],
          statuses: [{ status: 'protect', turns: 7 }],
          poisonResistance: 35,
        },
      },
    }
    const w = buildWorld(sw, { 'test-hero': hero }, undefined, poisons)
    expect(w.party[0]).toMatchObject({
      poisons: [
        { poisonId: 551, tickIndex: 0 },
        { poisonId: 555, tickIndex: 0 },
      ],
      extraStatuses: [{ status: 'protect', turns: 7 }],
      extraPoisonRes: 35,
    })
  })

  test('不同入口的 condition seed 完全隔离，未配置时不物化空 carrier', () => {
    const plain = buildWorld(
      { party: ['test-hero'], money: 0, inventory: [] },
      { 'test-hero': hero },
    )
    const poisoned = buildWorld(
      {
        party: ['test-hero'],
        money: 0,
        inventory: [],
        seedConditions: { 'test-hero': { poisonIds: [551] } },
      },
      { 'test-hero': hero },
      undefined,
      poisons,
    )
    expect(plain.party[0]).not.toHaveProperty('poisons')
    expect(plain.party[0]).not.toHaveProperty('extraStatuses')
    expect(poisoned.party[0]?.poisons).toEqual([{ poisonId: 551, tickIndex: 0 }])
  })

  test('入口 condition 未知/重复引用 fail-loud', () => {
    const start = (poisonIds: number[]): StartWorld => ({
      party: ['test-hero'],
      money: 0,
      inventory: [],
      seedConditions: { 'test-hero': { poisonIds } },
    })
    expect(() => buildWorld(start([999]), { 'test-hero': hero }, undefined, poisons)).toThrow(
      '未知毒',
    )
    expect(() => buildWorld(start([551, 551]), { 'test-hero': hero }, undefined, poisons)).toThrow(
      '重复',
    )
  })
  test('seedStats 的 0 是有效当前值，单字段覆盖不固化另一项', () => {
    const w = buildWorld(
      {
        party: ['test-hero'],
        money: 0,
        inventory: [],
        seedStats: { 'test-hero': { hp: 0 } },
      },
      { 'test-hero': hero },
    )
    expect(w.party[0]?.hp).toBe(0)
    expect(w.party[0]?.mp).toBe(100)
    expect(w.party[0]?.maxHP).toBe(150)
  })
  test('入口当前 HP 为 0 时不能同时播种好状态', () => {
    expect(() =>
      buildWorld(
        {
          party: ['test-hero'],
          money: 0,
          inventory: [],
          seedStats: { 'test-hero': { hp: 0 } },
          seedConditions: {
            'test-hero': { statuses: [{ status: 'protect', turns: 7 }] },
          },
        },
        { 'test-hero': hero },
        undefined,
        poisons,
      ),
    ).toThrow('死亡角色不能播种好状态 protect')
  })
  test('同一角色的不同入口只改当前 hp/mp，最大值与初始技能稳定继承定义', () => {
    const normal = buildWorld(
      { party: ['test-hero'], money: 0, inventory: [] },
      { 'test-hero': hero },
    )
    const wounded = buildWorld(
      {
        party: ['test-hero'],
        money: 0,
        inventory: [],
        seedStats: { 'test-hero': { hp: 12, mp: 3 } },
      },
      { 'test-hero': hero },
    )
    expect([normal.party[0]?.hp, normal.party[0]?.maxHP]).toEqual([150, 150])
    expect([wounded.party[0]?.hp, wounded.party[0]?.maxHP]).toEqual([12, 150])
    expect([wounded.party[0]?.mp, wounded.party[0]?.maxMP]).toEqual([3, 100])
    expect(wounded.learnedSkills).toEqual(normal.learnedSkills)
  })
  test('缺角色 → throw', () => {
    const sw: StartWorld = { party: ['nobody'], money: 0, inventory: [] }
    expect(() => buildWorld(sw, {})).toThrow('不在 actors')
  })
  test('party 引无 battler 的 actor → throw(经 instantiate)', () => {
    const sw: StartWorld = { party: ['villager'], money: 0, inventory: [] }
    expect(() => buildWorld(sw, { villager })).toThrow(/battler/)
  })

  test('新档直接构造 canonical script 与 lifecycle 空容器', () => {
    const sw: StartWorld = {
      party: ['test-hero'],
      money: 50,
      inventory: [{ itemId: '267', count: 1 }],
    }
    const w = buildWorld(sw, { 'test-hero': hero })
    expect(w.script).toEqual({ flags: {}, vars: {}, entityState: {}, behaviors: {} })
    expect(w.entityLifecycles).toEqual({})
    expect(w.party[0]?.template).toBe('test-hero')
    expect(w.inventory).toEqual([{ itemId: '267', count: 1 }])
  })
})

describe('buildWorld variable defaults', () => {
  test('seeds only a fresh world and keeps definition metadata out of runtime state', () => {
    const start: StartWorld = {
      party: ['test-hero'],
      money: 0,
      inventory: [],
    }
    const world = buildWorld(
      start,
      { 'test-hero': hero },
      {
        introSeen: { kind: 'flag', name: '已看开场', description: '作者说明', initial: true },
        reputation: { kind: 'number', name: '声望', description: '', initial: 3 },
      },
    )
    expect(world.script?.flags).toEqual({ introSeen: true })
    expect(world.script?.vars).toEqual({ reputation: 3 })
    expect(world).not.toHaveProperty('worldVariables')
  })
})

describe('applySetParty —— C7 队伍变更(D22 reserve 暂存区)', () => {
  const actors = {
    'test-hero': {
      id: 'test-hero',
      name: 't.hero',
      spriteId: 's1',
      battler: {
        baseStats: {
          level: 1,
          hp: 150,
          maxHP: 150,
          mp: 100,
          maxMP: 100,
          attack: 10,
          defense: 10,
          magicAttack: 10,
          speed: 10,
          luck: 10,
        },
        initialEquipment: {},
        initialMagic: ['hero-skill'],
      },
    },
    'test-mate': {
      id: 'test-mate',
      name: 't.mate',
      spriteId: 's2',
      battler: {
        baseStats: {
          level: 1,
          hp: 90,
          maxHP: 90,
          mp: 50,
          maxMP: 50,
          attack: 8,
          defense: 8,
          magicAttack: 8,
          speed: 8,
          luck: 8,
        },
        initialEquipment: {},
        initialMagic: ['mate-skill'],
      },
    },
  } as unknown as Record<string, import('./actor.js').ActorDef>

  function world(): WorldState {
    const w = buildWorld({ party: ['test-hero'], money: 0, inventory: [] }, actors)
    return w
  }

  test('新成员首次入队:从模板实例化', () => {
    const w = world()
    applySetParty(w, ['test-hero', 'test-mate'], actors)
    expect(w.party.map((c) => c.template)).toEqual(['test-hero', 'test-mate'])
    expect(w.party[1]?.hp).toBe(90)
    expect(w.learnedSkills['test-mate']).toEqual(['mate-skill'])
  })

  test('已有空技能键表示运行进度，首次入队也不重播', () => {
    const w = world()
    w.learnedSkills['test-mate'] = []
    applySetParty(w, ['test-hero', 'test-mate'], actors)
    expect(w.learnedSkills['test-mate']).toEqual([])
  })

  test('离队进 reserve,状态不丢;再入队原样搬回', () => {
    const w = world()
    applySetParty(w, ['test-hero', 'test-mate'], actors)
    w.party[1]!.hp = 7 // 打残
    w.party[1]!.poisons = [{ poisonId: 551, tickIndex: 2 }]
    w.party[1]!.extraStatuses = [{ status: 'protect', turns: 5 }]
    w.party[1]!.extraPoisonRes = 20
    applySetParty(w, ['test-hero'], actors) // mate 离队
    expect(w.party.map((c) => c.template)).toEqual(['test-hero'])
    expect(w.reserve?.map((c) => c.template)).toEqual(['test-mate'])
    expect(w.reserve?.[0]?.hp).toBe(7) // 不清数据
    applySetParty(w, ['test-hero', 'test-mate'], actors) // 回归
    expect(w.party[1]?.hp).toBe(7) // 原实例
    expect(w.party[1]).toMatchObject({
      poisons: [{ poisonId: 551, tickIndex: 2 }],
      extraStatuses: [{ status: 'protect', turns: 5 }],
      extraPoisonRes: 20,
    })
    expect(w.reserve).toEqual([])
  })

  test('setParty 后的显式 condition 命令独立生效，离队归队仍保留', () => {
    const w = world()
    applySetParty(w, ['test-hero', 'test-mate'], actors)
    applyActorCondition(
      w.party[1]!,
      {
        kind: 'status',
        status: 'protect',
        turns: 7,
      },
      poisons,
    )
    expect(w.party[1]?.extraStatuses).toEqual([{ status: 'protect', turns: 7 }])

    applySetParty(w, ['test-hero'], actors)
    expect(w.reserve?.[0]?.extraStatuses).toEqual([{ status: 'protect', turns: 7 }])
    applySetParty(w, ['test-hero', 'test-mate'], actors)
    expect(w.party[1]?.extraStatuses).toEqual([{ status: 'protect', turns: 7 }])
  })

  test('离队后的学习/遗忘进度在归队时不被出厂技能覆盖', () => {
    const w = world()
    applySetParty(w, ['test-hero', 'test-mate'], actors)
    w.learnedSkills['test-mate'] = ['learned-later']
    applySetParty(w, ['test-hero'], actors)
    applySetParty(w, ['test-hero', 'test-mate'], actors)
    expect(w.learnedSkills['test-mate']).toEqual(['learned-later'])

    w.learnedSkills['test-mate'] = []
    applySetParty(w, ['test-hero'], actors)
    applySetParty(w, ['test-hero', 'test-mate'], actors)
    expect(w.learnedSkills['test-mate']).toEqual([])
  })

  test('members 顺序 = 站位序(队长在前)', () => {
    const w = world()
    applySetParty(w, ['test-mate', 'test-hero'], actors)
    expect(w.party.map((c) => c.template)).toEqual(['test-mate', 'test-hero'])
  })

  test('在队成员保留原实例(引用不变)', () => {
    const w = world()
    const hero = w.party[0]!
    hero.hp = 42
    applySetParty(w, ['test-hero', 'test-mate'], actors)
    expect(w.party[0]).toBe(hero)
    expect(w.party[0]?.hp).toBe(42)
  })

  test('未知角色 id 抛错', () => {
    const w = world()
    expect(() => applySetParty(w, ['nobody'], actors)).toThrow(/不在 actors 表/)
  })

  test('入队中途失败不留队伍或技能半提交', () => {
    const w = world()
    const before = JSON.parse(JSON.stringify(w)) as WorldState
    expect(() => applySetParty(w, ['test-hero', 'test-mate', 'nobody'], actors)).toThrow(
      /不在 actors 表/,
    )
    expect(w).toEqual(before)
  })
})
