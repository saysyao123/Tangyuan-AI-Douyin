import { describe, expect, test } from 'vitest'
import type { EntityDef } from './index.js'
import { itemUseSupportsContext } from './item.js'
import { runtimeItemPrivateScriptRef } from './item-script-runtime-ref.js'
import {
  checkThrowSpec,
  validateActors,
  validateBattleFields,
  validateCurrentManifestStartup,
  validateEnemies,
  validateItems,
  validateLocale,
  validateScenes,
  validateSkills,
  validateSprites,
  validateStartWorld,
  validateStartWorldResources,
} from './validate.js'

const mkScene = (over: Record<string, unknown> = {}): unknown => ({
  id: 's',
  mapId: 'map-001',
  entry: { pos: { col: 0, row: 0, height: 0 }, facing: 'down' },
  entities: [],
  ...over,
})
const mkEnt = (ref: Record<string, unknown>): Record<string, unknown> => ({
  id: 'e',
  pos: { col: 0, row: 0, height: 0 },
  ...ref,
})

describe('validateScenes · 实体 actor ⊕ sprite(C0)', () => {
  test('actor 形态 / sprite 形态 → 各自通过', () => {
    expect(() =>
      validateScenes([mkScene({ entities: [mkEnt({ actor: 'youhun' })] })]),
    ).not.toThrow()
    expect(() => validateScenes([mkScene({ entities: [mkEnt({ sprite: 'vase' })] })])).not.toThrow()
  })
  test('两者都有 → throw(M3a:恰一 actor/sprite/zone)', () => {
    expect(() =>
      validateScenes([mkScene({ entities: [mkEnt({ actor: 'a', sprite: 's' })] })]),
    ).toThrow('现 2 个')
  })
  test('两者都无 → throw', () => {
    expect(() => validateScenes([mkScene({ entities: [mkEnt({})] })])).toThrow('现 0 个')
  })
  test('zone 触发区:zone:true 单独合法', () => {
    expect(() => validateScenes([mkScene({ entities: [mkEnt({ zone: true })] })])).not.toThrow()
  })
  test('zone 触发区拒绝无意义朝向，可见实体仍可声明朝向', () => {
    expect(() =>
      validateScenes([mkScene({ entities: [mkEnt({ zone: true, facing: 'down' })] })]),
    ).toThrow('zone 无朝向')
    expect(() =>
      validateScenes([mkScene({ entities: [mkEnt({ sprite: 'vase', facing: 'left' })] })]),
    ).not.toThrow()
  })

  test('zone 类型契约同样拒绝朝向字段', () => {
    const validZone: Extract<EntityDef, { zone: true }> = {
      id: 'zone',
      pos: { col: 0, row: 0, height: 0 },
      zone: true,
    }
    const invalidZone: Extract<EntityDef, { zone: true }> = {
      id: 'zone-facing',
      pos: { col: 0, row: 0, height: 0 },
      zone: true,
      // @ts-expect-error 当前 canonical zone 明确没有朝向。
      facing: 'down',
    }

    expect(validZone.zone).toBe(true)
    expect(invalidZone.zone).toBe(true)
  })
})

const mkBattlerActor = (battlerOver: Record<string, unknown>): unknown => ({
  id: 'hero',
  name: 'name.hero',
  spriteId: 'hero-sprite',
  battler: {
    battleSprite: 'hero-battle-sprite',
    baseStats: {} as never,
    initialEquipment: {},
    initialMagic: [],
    ...battlerOver,
  },
})

describe('validateActors · E18-1 三字段结构校验(K2)', () => {
  const validCasualty = {
    friendDeath: {
      gates: [{ chance: 75, branch: { lines: [{ text: 'dlg.1', style: 'bottom' }], effects: [] } }],
      fallback: { lines: [], effects: [{ kind: 'heal', resource: 'hp' }] },
    },
  }

  test('合法三字段 → 通过', () => {
    expect(() =>
      validateActors([
        mkBattlerActor({
          coveredBy: 'hero2',
          cooperativeMagicSkillId: '99',
          casualty: validCasualty,
        }),
      ]),
    ).not.toThrow()
  })
  test('coveredBy / cooperativeMagicSkillId 空串 → throw', () => {
    expect(() => validateActors([mkBattlerActor({ coveredBy: '' })])).toThrow('coveredBy')
    expect(() => validateActors([mkBattlerActor({ cooperativeMagicSkillId: '' })])).toThrow(
      'cooperativeMagicSkillId',
    )
  })
  test('chance 越界(0 / 101 / 非整数)→ throw', () => {
    for (const bad of [0, 101, 50.5]) {
      expect(() =>
        validateActors([
          mkBattlerActor({
            casualty: {
              friendDeath: {
                gates: [{ chance: bad, branch: { lines: [], effects: [] } }],
                fallback: { lines: [], effects: [] },
              },
            },
          }),
        ]),
      ).toThrow('chance')
    }
  })
  test('style 非法 / effect kind 非法 / percent <1 → throw', () => {
    expect(() =>
      validateActors([
        mkBattlerActor({
          casualty: {
            dying: {
              gates: [],
              fallback: { lines: [{ text: 'dlg.1', style: 'center' }], effects: [] },
            },
          },
        }),
      ]),
    ).toThrow('style')
    expect(() =>
      validateActors([
        mkBattlerActor({
          casualty: {
            dying: {
              gates: [],
              fallback: { lines: [], effects: [{ kind: 'nuke' }] },
            },
          },
        }),
      ]),
    ).toThrow('kind')
    expect(() =>
      validateActors([
        mkBattlerActor({
          casualty: {
            dying: {
              gates: [],
              fallback: {
                lines: [],
                effects: [{ kind: 'tempStatBuff', stat: 'attack', percent: 0 }],
              },
            },
          },
        }),
      ]),
    ).toThrow('percent')
  })
})

const layout = { kind: 'directional', framesPerDir: 3 }

describe('validateSprites(含 layout,C0)', () => {
  test('合法数组 → 原样返回', () => {
    const sprites = [
      { id: 'ghost', asset: 'sprite.ghost', label: '游魂', layout },
      { id: 'oldman', asset: 'sprite.oldman', label: '老者', layout: { kind: 'static' } },
      {
        id: 'pool',
        asset: 'sprite.pool',
        label: '血池',
        layout: { kind: 'static' },
        poses: {
          ripple: {
            label: '水波',
            order: 0,
            steps: [
              { frame: 0, durationMs: 100 },
              { frame: 1, durationMs: 200 },
            ],
            loopFrom: 0,
          },
        },
      },
    ]
    expect(validateSprites(sprites)).toEqual(sprites)
  })
  test('非数组 → throw', () => {
    expect(() => validateSprites({})).toThrow('期望数组')
  })
  test('缺 asset → throw', () => {
    expect(() => validateSprites([{ id: 'ghost', label: '游魂', layout }])).toThrow('缺键 "asset"')
  })
  test('旧 spriteNum/path 与空 asset → throw', () => {
    expect(() =>
      validateSprites([
        { id: 'ghost', asset: 'sprite.ghost', spriteNum: 16, label: '游魂', layout },
      ]),
    ).toThrow('spriteNum: 已退役')
    expect(() =>
      validateSprites([
        {
          id: 'ghost',
          asset: 'sprite.ghost',
          path: 'assets/sprites/ghost.rle',
          label: '游魂',
          layout,
        },
      ]),
    ).toThrow('path: 已退役')
    expect(() => validateSprites([{ id: 'ghost', asset: '', label: '游魂', layout }])).toThrow(
      '期望非空 AssetId',
    )
  })
  test('缺 layout → throw', () => {
    expect(() => validateSprites([{ id: 'ghost', asset: 'sprite.ghost', label: '游魂' }])).toThrow(
      '缺键 "layout"',
    )
  })
  test('layout.kind 非法 → throw', () => {
    expect(() =>
      validateSprites([{ id: 'g', asset: 'sprite.g', label: 'x', layout: { kind: 'walk' } }]),
    ).toThrow('kind 非法')
  })
  test('directional 缺 framesPerDir → throw', () => {
    expect(() =>
      validateSprites([
        { id: 'g', asset: 'sprite.g', label: 'x', layout: { kind: 'directional' } },
      ]),
    ).toThrow('缺 framesPerDir')
  })
  test('v4 拒绝旧 layout.loop 第二真值', () => {
    expect(() =>
      validateSprites([{ id: 'g', asset: 'sprite.g', label: 'x', layout: { kind: 'loop' } }]),
    ).toThrow('kind 非法')
  })
  test('布局计数必须是正整数，动作时间线完整校验', () => {
    for (const framesPerDir of [0, -1, 1.5])
      expect(() =>
        validateSprites([
          {
            id: 'g',
            asset: 'sprite.g',
            label: 'x',
            layout: { kind: 'directional', framesPerDir },
          },
        ]),
      ).toThrow(/正整数/)
    expect(() =>
      validateSprites([
        {
          id: 'g',
          asset: 'sprite.g',
          label: 'x',
          layout: { kind: 'static' },
          poses: { 坏动作: { label: '坏动作', steps: [] } },
        },
      ]),
    ).toThrow(/非空数组/)
    expect(() =>
      validateSprites([
        {
          id: 'g',
          asset: 'sprite.g',
          label: 'x',
          layout: { kind: 'static' },
          poses: { 坏动作: { label: '坏动作', steps: [{ frame: 0, durationMs: 0 }] } },
        },
      ]),
    ).toThrow(/durationMs: 期望正整数/)
    expect(() =>
      validateSprites([
        {
          id: 'g',
          asset: 'sprite.g',
          label: 'x',
          layout: { kind: 'static' },
          poses: {
            坏动作: {
              label: '坏动作',
              steps: [{ frame: 0, durationMs: 100, cues: [{ kind: 'dialog', asset: 'x' }] }],
            },
          },
        },
      ]),
    ).toThrow(/只允许 sound/)
    expect(() =>
      validateSprites([
        {
          id: 'g',
          asset: 'sprite.g',
          label: 'x',
          layout: { kind: 'static' },
          poses: {
            坏动作: {
              label: '坏动作',
              steps: [{ frame: 0, durationMs: 100 }],
              mode: 'loop',
            },
          },
        },
      ]),
    ).toThrow(/mode: 未知字段/)
  })
  test('id 唯一，且可与 catalog 的 sprite kind 交叉校验', () => {
    const def = { id: 'g', asset: 'sprite.g', label: 'x', layout: { kind: 'static' } }
    const record = {
      path: 'assets/authored/sprites/g.rle',
      mediaType: 'application/vnd.type-pal.rle',
      bytes: 1,
      sha256: 'a'.repeat(64),
      origin: { kind: 'authored' as const },
    }
    expect(() => validateSprites([def, def])).toThrow('重复 id')
    expect(() => validateSprites([def], { version: 1, assets: {} })).toThrow('不在 catalog')
    expect(() =>
      validateSprites([def], {
        version: 1,
        assets: { 'sprite.g': { ...record, kind: 'tileset' } },
      }),
    ).toThrow('期望 sprite')
    expect(
      validateSprites([def], {
        version: 1,
        assets: { 'sprite.g': { ...record, kind: 'sprite' } },
      }),
    ).toEqual([def])
  })
})

describe('validateActors(C0)', () => {
  const battler = {
    battleSprite: 'hero-battle-sprite',
    baseStats: {},
    initialEquipment: {},
    initialMagic: [],
  }
  test('合法(带/不带 battler)→ 原样返回', () => {
    const actors = [
      { id: 'youhun', name: 'name.youhun', spriteId: 'ghost' },
      { id: 'hero', name: 'name.hero', spriteId: 'hero-s', battler },
    ]
    expect(validateActors(actors)).toEqual(actors)
  })
  test('缺 spriteId → throw', () => {
    expect(() => validateActors([{ id: 'a', name: 'n' }])).toThrow('缺键 "spriteId"')
  })
  test('name 非 string → throw', () => {
    expect(() => validateActors([{ id: 'a', name: 1, spriteId: 's' }])).toThrow('name 非string')
  })
  test('battler 缺 baseStats → throw', () => {
    expect(() =>
      validateActors([
        { id: 'a', name: 'n', spriteId: 's', battler: { initialEquipment: {}, initialMagic: [] } },
      ]),
    ).toThrow('缺键 "baseStats"')
  })
  test('战斗音效只接受可选 AssetId，拒绝旧数字', () => {
    expect(() =>
      validateActors([
        {
          id: 'a',
          name: 'n',
          spriteId: 's',
          battler: { ...battler, sounds: { attack: 9 } },
        },
      ]),
    ).toThrow('期望非空 AssetId')
  })
  test('初始仙术必须是非空、不重复的 skill id 数组', () => {
    expect(() =>
      validateActors([
        { id: 'a', name: 'n', spriteId: 's', battler: { ...battler, initialMagic: '296' } },
      ]),
    ).toThrow(/initialMagic.*期望数组/)
    expect(() =>
      validateActors([
        { id: 'a', name: 'n', spriteId: 's', battler: { ...battler, initialMagic: [''] } },
      ]),
    ).toThrow(/期望非空 skill id/)
    expect(() =>
      validateActors([
        {
          id: 'a',
          name: 'n',
          spriteId: 's',
          battler: { ...battler, initialMagic: ['296', '296'] },
        },
      ]),
    ).toThrow(/初始仙术 "296" 重复/)
  })
  test('立绘组与 face 只接受 AssetId，expressions 全量检查', () => {
    expect(() =>
      validateActors([
        {
          id: 'a',
          name: 'n',
          spriteId: 's',
          portraits: { default: 'portrait.a', expressions: { hurt: 'portrait.a.hurt' } },
          face: 'face.a',
        },
      ]),
    ).not.toThrow()
    expect(() =>
      validateActors([{ id: 'a', name: 'n', spriteId: 's', portraits: { default: 1 } }]),
    ).toThrow('期望非空 AssetId')
    expect(() =>
      validateActors([
        {
          id: 'a',
          name: 'n',
          spriteId: 's',
          portraits: { default: 'portrait.a', expressions: { hurt: 2 } },
        },
      ]),
    ).toThrow('期望非空 AssetId')
    expect(() => validateActors([{ id: 'a', name: 'n', spriteId: 's', face: 1 }])).toThrow(
      '期望非空 AssetId',
    )
  })
})

test('技能、物品和敌人音效 guard 拒绝旧数字与负号协议', () => {
  expect(() =>
    validateSkills({
      skills: [
        {
          id: '1',
          name: 'n',
          cost: {},
          target: 'oneEnemy',
          effects: [],
          animation: { effectSprite: 1, sound: 45 },
        },
      ],
      levelUp: {},
    }),
  ).toThrow('期望非空 AssetId')
  expect(() =>
    validateItems([
      {
        id: '151',
        name: '引路蜂',
        desc: [],
        icon: 1,
        buyPrice: 1,
        sellPrice: 1,
        sellable: true,
        use: { target: 'oneAlly', consuming: true, effects: [], sound: 45 },
      },
    ]),
  ).toThrow('期望非空 AssetId')
  expect(() =>
    validateEnemies([
      {
        id: 'enemy-1',
        name: 'name.enemy-1',
        battleSprite: 'enemy-battle-1',
        yPosOffset: 0,
        stats: {},
        ai: { resistanceToSorcery: 0 },
        sounds: { magic: -47 },
      },
    ]),
  ).toThrow('期望非空 AssetId')
})

test('技能执行分支、直接资源变化、前置震屏与剩余 MP 语义可校验', () => {
  expect(() =>
    validateSkills({
      skills: [
        {
          id: '370',
          name: '酒神',
          cost: { mp: 1, items: [{ itemId: '86', amount: 1 }] },
          target: 'oneEnemy',
          effects: [],
          animation: { effectSprite: 34, preShake: { frames: 20, level: 3 } },
          execution: {
            player: {
              prepare: [
                { kind: 'remainingResourceDamage', resource: 'mp', multiplier: 8, consume: 'all' },
              ],
            },
            enemy: {
              effects: [{ kind: 'resourceDelta', resource: 'hp', delta: -1 }],
            },
          },
        },
      ],
      levelUp: {},
    }),
  ).not.toThrow()
  expect(() =>
    validateSkills({
      skills: [
        {
          id: 'x',
          name: 'x',
          cost: {},
          target: 'oneEnemy',
          effects: [],
          animation: { effectSprite: 1, preShake: { frames: 0, level: 3 } },
        },
      ],
      levelUp: {},
    }),
  ).toThrow('preShake.frames')
  expect(() =>
    validateSkills({
      skills: [
        {
          id: 'x',
          name: 'x',
          cost: {},
          target: 'oneEnemy',
          effects: [],
          animation: { effectSprite: 1 },
          execution: {
            player: {
              prepare: [
                { kind: 'remainingResourceDamage', resource: 'mp', multiplier: 8, consume: 'all' },
                { kind: 'remainingResourceDamage', resource: 'mp', multiplier: 8, consume: 'all' },
              ],
            },
          },
        },
      ],
      levelUp: {},
    }),
  ).toThrow('只允许一个前置资源效果')
})

test('敌方 execution 只允许 runtime 已实现效果且拒绝 prepare', () => {
  const bundle = (enemy: unknown) => ({
    skills: [
      {
        id: 'x',
        name: 'x',
        cost: {},
        target: 'oneEnemy',
        effects: [{ kind: 'damage', power: 1, elemental: 0 }],
        animation: { effectSprite: 1 },
        execution: { enemy },
      },
    ],
    levelUp: {},
  })
  expect(() =>
    validateSkills(bundle({ effects: [{ kind: 'resourceDelta', resource: 'hp', delta: -1 }] })),
  ).not.toThrow()
  expect(() => validateSkills(bundle({ effects: [{ kind: 'healMp', amount: 1 }] }))).toThrow(
    '敌方 runtime 不支持 healMp',
  )
  expect(() =>
    validateSkills(
      bundle({
        prepare: [
          { kind: 'remainingResourceDamage', resource: 'mp', multiplier: 8, consume: 'all' },
        ],
      }),
    ),
  ).toThrow('敌方 runtime 不支持施法前置效果')
})

test('SkillCost.items 只接受非空物品 ID 与正安全整数数量', () => {
  const bundle = (items: unknown) => ({
    skills: [
      {
        id: '352',
        name: '三尸咒',
        cost: { mp: 22, items },
        target: 'allEnemies',
        effects: [],
        animation: { effectSprite: 1 },
      },
    ],
    levelUp: {},
  })
  expect(() => validateSkills(bundle([{ itemId: '148', amount: 1 }]))).not.toThrow()
  expect(() => validateSkills(bundle([{ itemId: '', amount: 1 }]))).toThrow('期望非空物品 ID')
  expect(() => validateSkills(bundle([{ itemId: '148', amount: 0 }]))).toThrow('期望正整数')
  expect(() => validateSkills(bundle([{ itemId: '148', amount: 1.5 }]))).toThrow('期望整数')
  expect(() =>
    validateSkills(bundle([{ itemId: '148', amount: Number.MAX_SAFE_INTEGER + 1 }])),
  ).toThrow('期望安全整数')
  expect(() => validateSkills(bundle([{ itemId: '148', amount: 1, extra: true }]))).toThrow(
    '未知字段',
  )
})

test('技能 lifetimeLimit 只接受正安全整数，缺席表示不限', () => {
  const bundle = (lifetimeLimit?: unknown) => ({
    skills: [
      {
        id: '370',
        name: '酒神',
        cost: {},
        target: 'allEnemies',
        effects: [],
        animation: { effectSprite: 1 },
        ...(lifetimeLimit === undefined ? {} : { lifetimeLimit }),
      },
    ],
    levelUp: {},
  })
  expect(() => validateSkills(bundle())).not.toThrow()
  expect(() => validateSkills(bundle(9))).not.toThrow()
  for (const value of [0, -1, 1.5, '9', {}, Number.MAX_SAFE_INTEGER + 1])
    expect(() => validateSkills(bundle(value))).toThrow(/lifetimeLimit/)
})

test('物品图标和战场背景拒绝旧数字/路径字段，缺席语义合法', () => {
  const item = {
    id: '277',
    name: '无图物品',
    desc: [],
    buyPrice: 0,
    sellPrice: 0,
    sellable: false,
  }
  expect(validateItems([item])).toEqual([item])
  expect(() => validateItems([{ ...item, icon: 1 }])).toThrow('期望非空 AssetId')
  expect(() =>
    validateBattleFields([
      {
        id: 6,
        bg: 'battle/bg/006.png',
        screenWave: 0,
        magicEffect: { wind: 0, thunder: 0, water: 0, fire: 0, earth: 0 },
      },
    ]),
  ).toThrow('旧路径字段已退役')
  expect(() =>
    validateBattleFields([
      {
        id: 6,
        background: 6,
        screenWave: 0,
        magicEffect: { wind: 0, thunder: 0, water: 0, fire: 0, earth: 0 },
      },
    ]),
  ).toThrow('期望非空 AssetId')
})

describe('validateBattleFields · 持久表严格边界', () => {
  const field = (id: number): Record<string, unknown> => ({
    id,
    name: `战场 ${id}`,
    screenWave: 0,
    magicEffect: { wind: 0, thunder: 0, water: 0, fire: 0, earth: 0 },
  })

  test('id 必须是唯一的非负安全整数', () => {
    expect(() => validateBattleFields([field(24), field(24)])).toThrow('重复战场 id 24')
    for (const id of [-1, 1.5, Number.MAX_SAFE_INTEGER + 1])
      expect(() => validateBattleFields([field(id)])).toThrow('非负安全整数')
  })

  test('顶层与五行效果都拒绝未知/缺失字段', () => {
    expect(() => validateBattleFields([{ ...field(24), typo: true }])).toThrow('typo: 未知字段')
    const missing = field(24)
    delete (missing.magicEffect as Record<string, unknown>).earth
    expect(() => validateBattleFields([missing])).toThrow('缺键 "earth"')
    expect(() =>
      validateBattleFields([
        {
          ...field(24),
          magicEffect: {
            wind: 0,
            thunder: 0,
            water: 0,
            fire: 0,
            earth: 0,
            metal: 0,
          },
        },
      ]),
    ).toThrow('metal: 未知字段')
  })
})

describe('validateItems · 装备战斗形象按角色覆写', () => {
  const item = (effects: unknown[]) => ({
    id: 'weapon',
    name: '测试武器',
    desc: [],
    buyPrice: 0,
    sellPrice: 0,
    sellable: false,
    equip: { slot: 'weapon', equipableBy: ['hero', 'mage'], effects },
  })

  test('空映射与多角色映射合法，旧 sprite 字段 fail-closed', () => {
    expect(() =>
      validateItems([
        item([{ kind: 'battleSprite', byActor: {} }]),
        {
          ...item([{ kind: 'battleSprite', byActor: { hero: 'fighter-1', mage: 'fighter-2' } }]),
          id: 'weapon-2',
        },
      ]),
    ).not.toThrow()
    expect(() => validateItems([item([{ kind: 'battleSprite', sprite: 'fighter-1' }])])).toThrow(
      /sprite: 未知字段/,
    )
  })

  test('映射键值与单效果约束完整校验', () => {
    expect(() => validateItems([item([{ kind: 'battleSprite', byActor: { hero: '' } }])])).toThrow(
      /BattleSpriteDef.id/,
    )
    expect(() =>
      validateItems([item([{ kind: 'battleSprite', byActor: { ' hero ': 'fighter-1' } }])]),
    ).toThrow(/ActorDef.id/)
    expect(() =>
      validateItems([
        item([
          { kind: 'battleSprite', byActor: { hero: 'fighter-1' } },
          { kind: 'battleSprite', byActor: { mage: 'fighter-2' } },
        ]),
      ]),
    ).toThrow(/最多一个/)
  })
})

describe('validateItems · C8 用途能力契约', () => {
  const item = (use: unknown) => ({
    id: 'item',
    name: '测试物品',
    desc: [],
    buyPrice: 0,
    sellPrice: 0,
    sellable: false,
    use,
  })

  test('合法的世界、战斗和剧情用途均通过，gate 缺省 chance 表示原版 100 阈值', () => {
    expect(() =>
      validateItems([
        item({
          target: 'oneAlly',
          consuming: true,
          effects: [{ kind: 'gate' }, { kind: 'healHp', amount: 10 }],
        }),
        {
          ...item({
            target: 'allAllies',
            consuming: true,
            battleOnly: true,
            effects: [{ kind: 'hideParty', turns: 3 }],
          }),
          id: 'battle',
        },
        {
          ...item({
            target: 'scene',
            consuming: false,
            menuAfterUse: 'close',
            effects: [
              { kind: 'runSceneHook', hook: 'onTeleport', unavailableMessage: '这里不能使用' },
            ],
          }),
          id: 'scene',
        },
      ]),
    ).not.toThrow()
  })

  test('傀儡不能成为大世界携带状态，显式 battleOnly 仍可用', () => {
    const puppet = {
      target: 'oneAlly',
      consuming: true,
      effects: [{ kind: 'applyStatus', status: 'puppet', turns: 3 }],
    }
    expect(() => validateItems([item(puppet)])).toThrow(/battleOnly/)
    expect(() => validateItems([item({ ...puppet, battleOnly: true })])).not.toThrow()
  })

  test.each([
    [{ consuming: true, effects: [{ kind: 'healHp', amount: 1 }] }, /target: 期望/],
    [
      { target: 'oneAlly', consuming: 'yes', effects: [{ kind: 'healHp', amount: 1 }] },
      /consuming: 期望 boolean/,
    ],
    [
      { target: 'enemy', consuming: true, effects: [{ kind: 'healHp', amount: 1 }] },
      /target: 期望/,
    ],
    [{ target: 'oneAlly', consuming: true, effects: [{ kind: 'healHp', amount: 0 }] }, /不得为 0/],
    [
      { target: 'oneAlly', consuming: true, effects: [{ kind: 'revive', hpPercent: 101 }] },
      /不得大于 100/,
    ],
    [
      { target: 'oneAlly', consuming: true, effects: [{ kind: 'removeStatus', statuses: [] }] },
      /不得为空/,
    ],
    [{ target: 'oneAlly', consuming: true, effects: [{ kind: 'curePoison' }] }, /至少需要一个/],
    [{ target: 'oneAlly', consuming: true, effects: [{ kind: 'gate', chance: 0 }] }, /期望正数/],
    [
      { target: 'oneAlly', consuming: true, effects: [{ kind: 'hideParty', turns: 1 }] },
      /必须使用 allAllies/,
    ],
    [
      {
        target: 'scene',
        consuming: true,
        battleOnly: true,
        effects: [{ kind: 'runSceneHook', hook: 'onTeleport' }],
      },
      /battleOnly 用途包含不可用于战斗/,
    ],
    [
      {
        target: 'oneAlly',
        consuming: true,
        effects: [{ kind: 'runScript', script: { chunk: 'c', id: 's' } }],
      },
      /必须使用 scene/,
    ],
    [
      {
        target: 'scene',
        consuming: true,
        effects: [
          { kind: 'runSceneHook', hook: 'onTeleport' },
          { kind: 'healHp', amount: 1 },
        ],
      },
      /必须作为唯一效果/,
    ],
    [
      { target: 'scene', consuming: true, effects: [{ kind: 'healHp', amount: 1 }] },
      /scene 目标必须包含/,
    ],
    [
      {
        target: 'scene',
        consuming: false,
        effects: [
          {
            kind: 'craftRecipe',
            recipes: [
              {
                ingredients: [{ itemId: 'in', count: 1 }],
                products: [{ itemId: 'out', count: 1 }],
              },
            ],
          },
          { kind: 'healHp', amount: 1 },
        ],
      },
      /不能与角色或战斗效果混合/,
    ],
  ] as const)('拒绝非法用途 %#', (use, expected) => {
    expect(() => validateItems([item(use)])).toThrow(expected)
  })

  test('用途允许暂存空效果链，但投掷必须至少有一个效果', () => {
    expect(() =>
      validateItems([item({ target: 'scene', consuming: true, effects: [] })]),
    ).not.toThrow()
    expect(() =>
      validateItems([
        {
          ...item(undefined),
          id: 'empty-throw',
          throw: { target: 'oneEnemy', effects: [] },
        },
      ]),
    ).toThrow(/throw\.effects: 不得为空/)
    expect(itemUseSupportsContext({ target: 'scene', consuming: true, effects: [] }, 'world')).toBe(
      false,
    )
    expect(
      itemUseSupportsContext({ target: 'oneAlly', consuming: true, effects: [] }, 'battle'),
    ).toBe(false)
  })

  test.each([
    {
      target: 'oneEnemy',
      effects: [
        {
          kind: 'magicDamage',
          baseDamage: Number.MAX_SAFE_INTEGER + 1,
          element: 'none',
          strength: { kind: 'fixed', value: 1 },
        },
      ],
    },
    {
      target: 'oneEnemy',
      effects: [
        {
          kind: 'magicDamage',
          baseDamage: 1,
          element: 'none',
          strength: { kind: 'fixed', value: Number.MAX_SAFE_INTEGER + 1 },
        },
      ],
    },
    {
      target: 'oneEnemy',
      effects: [
        {
          kind: 'magicDamage',
          baseDamage: 1,
          element: 'none',
          strength: {
            kind: 'casterAttack',
            bonus: Number.MAX_SAFE_INTEGER + 1,
            multiplier: { kind: 'uniformInt', min: 0, max: 3 },
          },
        },
      ],
    },
    {
      target: 'oneEnemy',
      effects: [{ kind: 'fixedDamage', amount: Number.MAX_SAFE_INTEGER + 1 }],
    },
    {
      target: 'oneEnemy',
      effects: [
        {
          kind: 'currentHpDamage',
          numerator: 1,
          denominator: 2,
          bonus: 1,
          cap: Number.MAX_SAFE_INTEGER + 1,
        },
      ],
    },
    {
      target: 'oneEnemy',
      effects: [
        {
          kind: 'applyStatus',
          status: 'sleep',
          turns: Number.MAX_SAFE_INTEGER + 1,
          onResist: 'continue',
        },
      ],
    },
    {
      target: 'oneEnemy',
      effects: [{ kind: 'killIfHpAtMost', percent: Number.MAX_SAFE_INTEGER + 1 }],
    },
    {
      target: 'oneEnemy',
      effects: [
        {
          kind: 'damageAndHealCaster',
          damage: 1,
          heal: Number.MAX_SAFE_INTEGER + 1,
        },
      ],
    },
  ])('投掷全部数值边界拒绝非安全整数 %#', (thrown) => {
    expect(() => checkThrowSpec(thrown)).toThrow(/安全整数/)
  })

  test('运行时投影允许当前物品私有脚本与普通效果组合', () => {
    const privateRuntime = {
      kind: 'runScript' as const,
      script: runtimeItemPrivateScriptRef('item'),
    }
    expect(privateRuntime.script).toEqual({ chunk: '__author-item-private-runtime', id: 'item' })
    expect(() =>
      validateItems([
        item({
          target: 'scene',
          consuming: false,
          effects: [privateRuntime],
        }),
        {
          ...item(undefined),
          id: 'mixed',
          use: {
            target: 'oneAlly',
            consuming: true,
            effects: [
              {
                kind: 'runScript',
                script: { chunk: '__author-item-private-runtime', id: 'mixed' },
              },
              { kind: 'healHp', amount: 1 },
            ],
          },
        },
      ]),
    ).not.toThrow()
    expect(() =>
      validateItems([
        item({
          target: 'oneAlly',
          consuming: true,
          effects: [privateRuntime, { kind: 'healHp', amount: 1 }],
        }),
      ]),
    ).not.toThrow()
    expect(() =>
      validateItems([
        item({
          target: 'oneAlly',
          consuming: true,
          effects: [
            {
              kind: 'runScript',
              script: { chunk: '__author-script-runtime', id: 'item:other:use' },
            },
            { kind: 'healHp', amount: 1 },
          ],
        }),
      ]),
    ).toThrow(/必须作为唯一效果/)
  })

  test('合法 item: 前缀共享脚本仍是外部效果，不因同名 owner 获得私有混合权限', () => {
    expect(() =>
      validateItems([
        item({
          target: 'oneAlly',
          consuming: true,
          effects: [
            {
              kind: 'runScript',
              script: { chunk: '__author-script-runtime', id: 'item:item:use' },
            },
            { kind: 'healHp', amount: 1 },
          ],
        }),
      ]),
    ).toThrow('必须作为唯一效果')
    expect(() =>
      validateItems([
        item({
          target: 'scene',
          consuming: true,
          effects: [
            {
              kind: 'runScript',
              script: { chunk: '__author-script-runtime', id: 'item:item:use' },
            },
          ],
        }),
      ]),
    ).not.toThrow()
  })

  test('配方与资源池完整校验，投掷拒绝世界专用效果', () => {
    expect(() =>
      validateItems([
        item({
          target: 'scene',
          consuming: false,
          effects: [
            {
              kind: 'drawFromResourcePool',
              resource: 'collectValue',
              maxRoll: 2,
              rewards: [
                { itemId: 'one', count: 1 },
                { itemId: 'two', count: 1 },
              ],
            },
          ],
        }),
      ]),
    ).not.toThrow()
    expect(() =>
      validateItems([
        item({
          target: 'scene',
          consuming: false,
          effects: [
            {
              kind: 'craftRecipe',
              recipes: [{ ingredients: [], products: [{ itemId: 'out', count: 1 }] }],
            },
          ],
        }),
      ]),
    ).toThrow(/ingredients: 不得为空/)
    expect(() =>
      validateItems([
        item({
          target: 'scene',
          consuming: false,
          effects: [
            {
              kind: 'drawFromResourcePool',
              resource: 'collectValue',
              maxRoll: 2,
              rewards: [{ itemId: 'one', count: 1 }],
            },
          ],
        }),
      ]),
    ).toThrow(/档位数必须恰好等于 maxRoll/)
    expect(() =>
      validateItems([
        item({
          target: 'scene',
          consuming: false,
          effects: [
            {
              kind: 'drawFromResourcePool',
              resource: 'collectValue',
              maxRoll: 2,
              rewards: [
                { itemId: 'one', count: 1 },
                { itemId: 'two', count: 1 },
                { itemId: 'unreachable', count: 1 },
              ],
            },
          ],
        }),
      ]),
    ).toThrow(/档位数必须恰好等于 maxRoll/)
    expect(() =>
      validateItems([
        {
          ...item(undefined),
          throw: {
            target: 'oneEnemy',
            effects: [
              {
                kind: 'craftRecipe',
                recipes: [
                  {
                    ingredients: [{ itemId: 'in', count: 1 }],
                    products: [{ itemId: 'out', count: 1 }],
                  },
                ],
              },
            ],
          },
        },
      ]),
    ).toThrow(/未知投掷效果/)
  })

  test('消耗型配方工具不能又把自身列为材料', () => {
    expect(() =>
      validateItems([
        item({
          target: 'scene',
          consuming: true,
          effects: [
            {
              kind: 'craftRecipe',
              recipes: [
                {
                  ingredients: [{ itemId: 'item', count: 1 }],
                  products: [{ itemId: 'out', count: 1 }],
                },
              ],
            },
          ],
        }),
      ]),
    ).toThrow(/不能同时作为自身配方材料/)
  })
})

describe('validateStartWorldResources', () => {
  const startWorld = (resources?: unknown): unknown => ({
    party: [],
    money: 0,
    inventory: [],
    ...(resources === undefined ? {} : { resources }),
  })

  test('允许零值与自定义非负安全整数', () => {
    expect(() => validateStartWorldResources(startWorld({ herb: 0, essence: 9 }))).not.toThrow()
  })

  test.each([
    [{ '': 1 }, /资源键不能为空/],
    [{ ' herb': 1 }, /不得包含首尾空格/],
    [{ 'herb ': 1 }, /不得包含首尾空格/],
    [{ collectValue: 1 }, /保留资源/],
    [{ herb: -1 }, /非负安全整数/],
    [{ herb: 1.5 }, /非负安全整数/],
    [{ herb: Number.POSITIVE_INFINITY }, /非负安全整数/],
  ])('拒绝非法资源池 %#', (resources, expected) => {
    expect(() => validateStartWorldResources(startWorld(resources))).toThrow(expected)
  })
})

describe('validateStartWorld · 入口角色当前状态', () => {
  const start = (seedConditions?: unknown): unknown => ({
    party: ['hero'],
    money: 0,
    inventory: [],
    ...(seedConditions === undefined ? {} : { seedConditions }),
  })

  test('接受稀疏空值与三类 carrier', () => {
    expect(() => validateStartWorld(start())).not.toThrow()
    expect(() => validateStartWorld(start({ hero: {} }))).not.toThrow()
    expect(() =>
      validateStartWorld(
        start({
          hero: {
            poisonIds: [551, 555],
            statuses: [{ status: 'protect', turns: 7 }],
            poisonResistance: 120,
          },
        }),
      ),
    ).not.toThrow()
  })

  test.each([
    [{ outsider: {} }, /已入队/],
    [{ hero: { poisonIds: [551, 551] } }, /重复/],
    [{ hero: { poisonIds: [0] } }, /PoisonDef\.id/],
    [{ hero: { statuses: [{ status: 'puppet', turns: 1 }] } }, /不可携带/],
    [{ hero: { statuses: [{ status: 'protect', turns: 0 }] } }, /正安全整数/],
    [{ hero: { statuses: [{ status: 'protect', turns: 1000 }] } }, /999/],
    [{ hero: { poisonResistance: 0 } }, /正安全整数/],
    [{ hero: { tickIndex: 2 } }, /未知字段/],
  ])('拒绝非队员、重复/内部字段与非法值 %#', (seedConditions, expected) => {
    expect(() => validateStartWorld(start(seedConditions))).toThrow(expected)
  })
})

describe('validateLocale · 对话行边界', () => {
  test('新内容禁止 locale 内换行；loader 兼容边界可显式保留旧软换行', () => {
    expect(() => validateLocale({ old: '第一行\n第二行' })).toThrow(/DialogueCue\.rows/)
    expect(validateLocale({ old: '第一行\n第二行' }, { allowSoftWrap: true })).toEqual({
      old: '第一行\n第二行',
    })
  })
})

describe('validateCurrentManifestStartup · canonical content22 startup model', () => {
  const world = () => ({ party: [], money: 0, inventory: [] })
  const entry = (id: string, scene = `scene-${id}`) => ({
    id,
    label: id,
    scene,
    startWorld: world(),
  })
  const manifest = () => ({
    id: 'demo',
    name: 'Demo',
    contentVersion: 22,
    minimumSaveVersion: 12,
    defaultEntryId: 'main',
    entryPoints: [entry('main')],
    content: { scenes: 'content/scenes/' },
    assets: { catalog: 'assets/index.json', roles: {} },
  })

  test('接受非首项 default，并按稳定 id 返回真实入口', () => {
    const value = {
      ...manifest(),
      defaultEntryId: 'dlc-b',
      entryPoints: [entry('main'), entry('dlc-b')],
    }
    expect(
      validateCurrentManifestStartup(value, ['scene-main', 'scene-dlc-b']).defaultEntry.id,
    ).toBe('dlc-b')
  })

  test.each([
    [{ ...manifest(), entryPoints: [] }, /至少需要一个真实入口/],
    [{ ...manifest(), defaultEntryId: 'missing' }, /defaultEntryId.*missing.*不存在/],
    [
      { ...manifest(), entryPoints: [entry('main'), entry('main', 'scene-other')] },
      /入口 id "main" 重复/,
    ],
    [{ ...manifest(), entryScene: 'scene-main' }, /entryScene: 未知字段/],
    [{ ...manifest(), startWorld: world() }, /startWorld: 未知字段/],
    [{ ...manifest(), contentVersion: 21 }, /contentVersion: 期望 22/],
    [
      {
        ...manifest(),
        entryPoints: [
          {
            ...entry('main'),
            startWorld: { ...world(), learnedSkills: { hero: ['296'] } },
          },
        ],
      },
      /learnedSkills: 未知字段/,
    ],
  ])('拒绝旧形状或破坏 canonical invariant %#', (value, expected) => {
    expect(() => validateCurrentManifestStartup(value)).toThrow(expected)
  })

  test('非默认入口错误使用稳定入口 id 定位，数组重排不改变路径', () => {
    const broken = { ...entry('dlc-b'), startWorld: { ...world(), seedStats: [] } }
    for (const entryPoints of [
      [entry('main'), broken],
      [broken, entry('main')],
    ])
      expect(() => validateCurrentManifestStartup({ ...manifest(), entryPoints })).toThrow(
        /entryPoints\[dlc-b\]\.startWorld\.seedStats/,
      )
  })

  test('所有入口场景都必须存在于索引，包括非默认入口', () => {
    const value = { ...manifest(), entryPoints: [entry('main'), entry('dlc-b')] }
    expect(() => validateCurrentManifestStartup(value, ['scene-main'])).toThrow(
      /entryPoints\[dlc-b\]\.scene.*不在 scenes\/index\.json/,
    )
  })
})
