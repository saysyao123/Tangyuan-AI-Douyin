import { createReadStream, statSync } from 'node:fs'
import { dirname, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import basicSsl from '@vitejs/plugin-basic-ssl'
import react from '@vitejs/plugin-react'
import type { Plugin } from 'vite'

/**
 * editor vite 配置(抄 reforge/vite.config.ts 的 serveDir)。
 *
 * 映射(跨平台,无 symlink,macOS/Linux/Windows 一致):
 *   /projects/*  → <repo-root>/projects/*     (工程 JSON + assets;loader fetch)
 *   /extracted/* → <repo-root>/data/extracted/* (原版提取资源;tilemap/sprite/palette)
 *
 * editor 复用 reforge 的 loadProject → 同样需要这两条映射。
 */
const repoRoot = resolve(dirname(fileURLToPath(import.meta.url)), '..', '..')
const lanHttps = process.env.EDITOR_LAN_HTTPS === '1'

function serveDir(urlPrefix: string, fsDir: string): Plugin {
  // dev + preview 同款中间件(见 reforge/vite.config.ts;⚠ 去前导斜杠 bug 已修,照抄)。
  const mw = (
    req: { url?: string },
    res: NodeJS.WritableStream & {
      setHeader?: (k: string, v: string) => void
      removeHeader?: (k: string) => void
      statusCode?: number
      end?: (body?: string) => void
    },
    next: () => void,
  ): void => {
    const url = req.url ?? ''
    if (!url.startsWith(urlPrefix)) {
      next()
      return
    }
    // 去前缀 + query + 前导斜杠;防路径穿越(../)。
    const rel = decodeURIComponent(url.slice(urlPrefix.length).split('?')[0] ?? '').replace(
      /^\/+/,
      '',
    )
    if (rel.includes('..')) {
      next()
      return
    }
    const file = resolve(fsDir, rel)
    if (!file.startsWith(fsDir)) {
      next()
      return
    }
    const saveState =
      urlPrefix === '/projects' &&
      /^[^/]+\/(?:\.type-pal\/save-state|editor\/(?:battle-simulator|script-preview))\.json$/.test(
        rel,
      )
    try {
      const stat = statSync(file)
      if (!stat.isFile()) {
        if (saveState) {
          res.statusCode = 500
          res.setHeader?.('Cache-Control', 'no-store')
          res.end?.()
          return
        }
        next()
        return
      }
    } catch (error) {
      // Optional recovery/editor metadata must not fall through to the SPA's 200 HTML response.
      if (saveState) {
        res.statusCode = (error as { code?: string }).code === 'ENOENT' ? 404 : 500
        res.setHeader?.('Cache-Control', 'no-store')
        res.end?.()
        return
      }
      next()
      return
    }
    // canonical .rle 的 gzip 是文件内容，不是 HTTP Content-Encoding；代理也不得 transform。
    res.setHeader?.('Cache-Control', 'no-cache, no-transform')
    if (saveState) {
      res.setHeader?.('Cache-Control', 'no-store')
      res.setHeader?.('Content-Type', 'application/json; charset=utf-8')
    }
    res.removeHeader?.('Content-Encoding')
    if (file.endsWith('.rle')) {
      res.setHeader?.('Content-Type', 'application/vnd.type-pal.rle')
      res.setHeader?.('X-Content-Type-Options', 'nosniff')
    } else if (file.endsWith('.gz')) {
      res.setHeader?.('Content-Type', 'application/gzip')
      res.setHeader?.('X-Content-Type-Options', 'nosniff')
    }
    // .js 必须带 JS MIME:audioWorklet.addModule 严格校验 Content-Type(fetch 不挑,worklet 挑)
    if (file.endsWith('.js') || file.endsWith('.mjs'))
      res.setHeader?.('Content-Type', 'text/javascript')
    createReadStream(file).pipe(res)
  }
  return {
    name: `serve-${urlPrefix.replace(/\//g, '')}`,
    configureServer(server) {
      server.middlewares.use(mw)
    },
    configurePreviewServer(server) {
      server.middlewares.use(mw)
    },
  }
}

export default {
  build: {
    rolldownOptions: {
      // 多页:主编辑器 + 同源试玩页 + 与业务数据隔离的 Design Lab。
      input: {
        main: resolve(dirname(fileURLToPath(import.meta.url)), 'index.html'),
        play: resolve(dirname(fileURLToPath(import.meta.url)), 'play.html'),
        designLab: resolve(dirname(fileURLToPath(import.meta.url)), 'design-lab.html'),
      },
      output: {
        // Size splitting exposes cyclic chunk edges; preserve source initialization order.
        strictExecutionOrder: true,
        codeSplitting: {
          // Split by actual entry usage without merging editor code into Design Lab or play.
          // Keep HTML facades outside the module group so their entry chunks remain intact.
          // maxSize targets module bytes; the default minified chunk warning still applies.
          groups: [
            {
              name: 'modules',
              test: /\.[cm]?[jt]sx?(?:\?|$)/,
              entriesAware: true,
              maxSize: 500_000,
            },
          ],
        },
      },
    },
  },
  plugins: [
    // File System Access 只在 secure context 暴露。localhost 的 HTTP 有浏览器豁免，
    // 局域网 IP 没有；dev:lan 才启用自签 HTTPS，日常 localhost dev 仍保持 HTTP。
    ...(lanHttps ? [basicSsl()] : []),
    react(),
    serveDir('/projects', resolve(repoRoot, 'projects')),
    serveDir('/extracted', resolve(repoRoot, 'data/extracted')),
    // W5 BGM 试听:reforge BgmPlayer 按应用绝对路径拉 worklet + soundfont(在 reforge/public);
    // editor 不复制 6MB 资产,单文件映射过去(serveDir prefix=完整路径 → rel='' → 命中该文件)。
    serveDir('/soundfont.sf3', resolve(repoRoot, 'packages/reforge/public/soundfont.sf3')),
    serveDir(
      '/spessasynth_processor.min.js',
      resolve(repoRoot, 'packages/reforge/public/spessasynth_processor.min.js'),
    ),
  ],
}
