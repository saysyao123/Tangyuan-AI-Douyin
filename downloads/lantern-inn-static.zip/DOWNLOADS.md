# Separate source and content downloads

Complete corresponding GPL source is offered alongside this distribution at:
https://lantern-inn-typepal-t1.ardentfern6.chatgpt.site/downloads/corresponding-source.zip

Canonical content22 project:
https://lantern-inn-typepal-t1.ardentfern6.chatgpt.site/downloads/lantern-inn-project.zip

GitHub source and reproducible build scripts:
https://github.com/saysyao123/Tangyuan-AI-Douyin/tree/main/09_GAME_ADAPTATION/BOOK_TO_RPG_PIPELINE_V1
